# FraudShield AI — Financial Fraud Risk Scoring

An end-to-end machine-learning application for ranking payment transactions by fraud risk, comparing supervised and anomaly-detection models, explaining predictions with SHAP, and reviewing results in a Streamlit dashboard.

> **Risk score, not a verdict.** Scores are model outputs on a 0–1 display scale. They are not calibrated probabilities and are not directly comparable across model families. Use them to prioritise human review, not as an automatic fraud determination.

## What changed in this revision

- **Future-oriented evaluation by default.** The latest 20% of transactions by `Time` is held out for final testing; the preceding 16% is validation; the earliest 64% is training. Transactions sharing an identical timestamp are kept in the same partition. `TimeSeriesSplit` is used for tuning the training period. A stratified random split remains available as a benchmark.
- **Fold-local preprocessing.** The preprocessor is inside every estimator pipeline. Each CV fold fits its own Amount scaler; SMOTE runs only inside the Random Forest training fold.
- **Cyclical time encoding.** `Time` is elapsed seconds since the dataset's first transaction, not a wall-clock timestamp. It is represented by a sine/cosine daily-cycle pair, avoiding the discontinuity between the end and start of a day.
- **Cost-sensitive decision thresholds.** Each model's threshold is selected on validation data by minimizing configurable weighted false-negative/false-positive cost. Defaults are relative weights of 10:1, not monetary estimates; set them to match the operation you intend to simulate.
- **Correct model-score terminology.** The app calls outputs `risk_score`, not `fraud_probability`. This avoids interpreting class-weighted, resampled, and anomaly scores as calibrated probabilities.
- **Consistent Isolation Forest explanations.** Permutation SHAP explains the same normalized `anomaly_score()` function used for prediction, so its baseline plus feature contributions reconstruct the displayed score (up to numerical tolerance).
- **Versioned artifact runs.** A complete training run is written to `models/runs/<run_id>/`. The active metadata pointer is switched atomically only after the run is complete. A failed run cannot replace the currently active model set, and reports from prior runs cannot be mistaken for current ones.
- **Safer input validation.** Non-finite values, including positive/negative infinity, are rejected before model inference.
- **Clear dashboard semantics.** The KPI now says `Not flagged`, not `Legitimate`, because an unflagged transaction can still be fraudulent.

## Models

| Model | Imbalance strategy | Score semantics |
|---|---|---|
| Logistic Regression | Balanced class weights | Classifier score; not calibrated |
| Random Forest | SMOTE inside training/CV pipeline (or balanced class weights if imbalanced-learn is unavailable) | Classifier score; not calibrated |
| XGBoost | `scale_pos_weight` based on the training split | Classifier score; not calibrated |
| Isolation Forest | Unsupervised fit | Normalized anomaly score; not a probability |

Models are compared primarily using **validation PR-AUC**. Test metrics are reported on the untouched latest-time holdout. A per-model operating threshold is selected from validation scores using the chosen relative error-cost weights. The dashboard also reports precision, recall, F1, ROC-AUC, PR-AUC, confusion counts and weighted error-cost units.

## Project structure

```text
FraudShield-AI/
├── app.py
├── train.py
├── requirements.txt
├── README.md
├── data/                         # put creditcard.csv here (git-ignored)
├── notebooks/01_eda.ipynb
├── models/
│   ├── metadata.json             # active run pointer/metadata, written last
│   └── runs/<run_id>/            # immutable model and report bundle
├── reports/                      # legacy placeholder; active reports are run-scoped
├── src/
│   ├── config.py
│   ├── data_loader.py
│   ├── eda.py
│   ├── models.py
│   ├── preprocessing.py
│   ├── evaluate.py
│   ├── explain.py
│   ├── predict.py
│   └── utils.py
├── dashboard/
│   ├── data.py                   # run-aware Streamlit caches
│   ├── components.py
│   └── views/
└── tests/test_pipeline.py
```

## Setup

Requires 64-bit Python 3.10–3.12.

### 1. Create an environment and install dependencies

**Windows PowerShell**

```powershell
cd FraudShield-AI
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

**macOS / Linux**

```bash
cd FraudShield-AI
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

On macOS, XGBoost may require OpenMP: `brew install libomp`.

### 2. Get the dataset

Download the Kaggle [Credit Card Fraud Detection](https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud) dataset and put `creditcard.csv` in `data/creditcard.csv`. See `data/README.md` for the Kaggle CLI method.

### 3. Train

```bash
python train.py
```

Quick run without randomized search:

```bash
python train.py --no-tune
```

Useful options:

```bash
python train.py --models logistic_regression random_forest
python train.py --n-iter 12 --cv 4
python train.py --split-strategy stratified
python train.py --false-negative-cost 20 --false-positive-cost 1
python train.py --skip-eda
```

`chronological` is the default and recommended evaluation mode. If one chronological partition contains only one class, training stops with an explicit message rather than silently falling back to random splitting. Use `--split-strategy stratified` for a random benchmark or when the data sample is too small for chronological evaluation. For a real future-facing system, the dataset must cover a sufficiently long time range and contain enough fraud examples in each period.

The default threshold weights (false-negative cost 10, false-positive cost 1) are only an example of relative operational priorities. They are not dollar amounts, and the right setting depends on investigation cost, customer friction, fraud loss, and review capacity.

### 4. Launch the dashboard

```bash
streamlit run app.py
```

Open `http://localhost:8501`.

### 5. Run tests

```bash
pytest -q
```

The test suite uses generated synthetic data to exercise implementation paths. It does **not** establish real-world fraud-detection performance; always run the complete training workflow against the actual Kaggle dataset before interpreting performance numbers.

## Dashboard pages

| Page | What it shows |
|---|---|
| Overview | Held-out transaction totals, flagged/not-flagged counts, detection rate and score distributions |
| Analyze Transaction | Single and batch scoring with a model-specific threshold and SHAP explanation |
| Transaction History | Filterable held-out test predictions, actual labels and local explanations |
| Model Performance | Held-out precision, recall, F1, ROC-AUC, PR-AUC, weighted error cost and curves |
| Explainable AI | Global SHAP feature importance and per-transaction explanations |
| Data & Methodology | Data lineage, split strategy, feature processing, costs and limitations |

## Technical notes and limitations

- The Kaggle dataset has 284,807 transactions and 492 fraud cases across roughly two days in 2013. It represents one European card issuer and an old fraud environment.
- The `Time` column is elapsed seconds from the first transaction. A modulo-24-hour cycle is a useful engineered periodic feature, but it is not actual local time or a calendar timestamp.
- `V1`–`V28` are anonymised PCA components; their original business meanings are unavailable.
- A chronological holdout is more realistic than a random split for estimating future performance, but two days of data are far too little to establish robustness to long-term concept drift. A production evaluation needs later, independently collected periods.
- Scores are not calibrated probabilities. If calibrated probabilities are required, add a separate calibration period and assess calibration with Brier score, log loss and calibration curves. Do not calibrate and tune the decision threshold on the same small validation sample without acknowledging the additional selection bias.
- The 10:1 false-negative/false-positive defaults are illustrative relative weights. Set cost weights from actual business loss and review operations before using the threshold for any consequential decision.
- FraudShield is a research/demo application, not a production payment authorization service. A real deployment needs monitoring, drift detection, secure data handling, access controls, audit logging, fail-safe behavior, periodic retraining and human review.

## Troubleshooting

| Problem | Fix |
|---|---|
| Dataset not found | Place the file at `data/creditcard.csv`. |
| Chronological split has one class | Inspect fraud counts over time; use a larger time range or `--split-strategy stratified` for a benchmark. |
| Dashboard says no trained models | Run `python train.py` successfully, then refresh. |
| `ModuleNotFoundError: src` | Run commands from the project root. |
| XGBoost `libomp` error on macOS | Install OpenMP with `brew install libomp`. |
| SHAP unavailable for a model | Install the requirements and rerun training; local explanations are then built from that run's artifacts. |
| Training too slow | Try `python train.py --no-tune`, reduce `--n-iter`, or train a subset with `--models`. |

## Licence and credits

Dataset: Machine Learning Group, Université Libre de Bruxelles (ULB), via Kaggle (ODbL). Follow the dataset's licence and attribution requirements.
