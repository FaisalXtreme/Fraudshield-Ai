"""Versioned FraudShield AI training pipeline.

All new artifacts are written into an isolated run directory. The active metadata
pointer is atomically replaced only after models, reports and explanations are ready.

Usage:
    python train.py
    python train.py --no-tune
    python train.py --models xgboost random_forest
    python train.py --split-strategy stratified  # random benchmark / small-data fallback
"""
from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import sys
import time
import uuid
from datetime import datetime
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.model_selection import RandomizedSearchCV, StratifiedKFold, TimeSeriesSplit

from src import config
from src.data_loader import DatasetNotFoundError, clean_dataset, load_dataset
from src.eda import run_eda
from src.evaluate import (
    best_f1_threshold, compute_metrics, cost_sensitive_threshold, curve_points,
    plot_confusion_matrices, plot_curves,
)
from src.explain import FraudExplainer, save_global_plots
from src.models import (
    ISOLATION_FOREST_GRID, available_models, build_training_pipeline, param_space,
)
from src.predict import risk_level
from src.preprocessing import split_data
from src.utils import get_logger, save_json

log = get_logger()


def parse_args():
    p = argparse.ArgumentParser(description="Train FraudShield AI models")
    p.add_argument("--data", default=str(config.DATASET_PATH), help="Path to creditcard.csv")
    p.add_argument("--models", nargs="+", choices=list(config.MODEL_NAMES), help="Subset of models to train")
    p.add_argument("--no-tune", action="store_true", help="Skip hyper-parameter search")
    p.add_argument("--n-iter", type=int, default=8, help="Randomized-search iterations per model")
    p.add_argument("--cv", type=int, default=3, help="Cross-validation folds for tuning (minimum 2)")
    p.add_argument("--split-strategy", choices=["chronological", "stratified"], default="chronological",
                   help="Chronological is recommended for future-transaction evaluation")
    p.add_argument("--false-negative-cost", type=float, default=10.0,
                   help="Relative cost weight for a missed fraud when selecting the threshold")
    p.add_argument("--false-positive-cost", type=float, default=1.0,
                   help="Relative cost weight for incorrectly flagging a legitimate transaction")
    p.add_argument("--skip-eda", action="store_true", help="Skip EDA figure generation")
    return p.parse_args()


def tune_or_fit(key, X_tr, y_tr, X_val, y_val, spw, args):
    """Fit a full raw-data pipeline; preprocessing/SMOTE occur inside each CV fold."""
    if key == "isolation_forest":
        from sklearn.metrics import average_precision_score
        grid = ISOLATION_FOREST_GRID if not args.no_tune else ISOLATION_FOREST_GRID[:1]
        best, best_ap, best_cfg = None, -1.0, None
        for cfg in grid:
            candidate = build_training_pipeline(key, isolation_params=cfg)
            candidate.fit(X_tr, y_tr)
            score = candidate.predict_proba(X_val)[:, 1]
            ap = average_precision_score(y_val, score)
            log.info("   IsolationForest %s -> val PR-AUC %.4f", cfg, ap)
            if ap > best_ap:
                best, best_ap, best_cfg = candidate, ap, cfg
        return best, best_cfg

    model = build_training_pipeline(key, scale_pos_weight=spw)
    space = param_space(key, model)
    if args.no_tune or not space:
        model.fit(X_tr, y_tr)
        return model, {}

    if args.split_strategy == "chronological":
        splitter = TimeSeriesSplit(n_splits=args.cv)
        cv_label = "expanding-window TimeSeriesSplit"
    else:
        splitter = StratifiedKFold(n_splits=args.cv, shuffle=True, random_state=config.RANDOM_STATE)
        cv_label = "StratifiedKFold"

    # Time-ordered folds can contain no fraud in an early validation window, or too
    # few fraud examples for SMOTE's neighbourhood. Detect that explicitly instead
    # of allowing undefined AP scores or an opaque SMOTE exception mid-search.
    cv_splits = list(splitter.split(X_tr, y_tr))
    for fold_number, (fit_idx, valid_idx) in enumerate(cv_splits, start=1):
        y_fit, y_valid = y_tr[fit_idx], y_tr[valid_idx]
        if np.unique(y_fit).size < 2:
            raise ValueError(f"{cv_label} fold {fold_number} training portion contains only one class.")
        if np.unique(y_valid).size < 2:
            raise ValueError(
                f"{cv_label} fold {fold_number} validation portion contains only one class; "
                "average precision would not be meaningful. Increase the training sample, "
                "adjust the time period, or use --split-strategy stratified as a benchmark."
            )
        if key == "random_forest":
            from src.models import HAS_IMBLEARN
            if HAS_IMBLEARN and int(np.sum(y_fit == 1)) <= 3:
                raise ValueError(
                    f"{cv_label} fold {fold_number} has fewer than four fraud examples in its "
                    "training portion; SMOTE with k_neighbors=3 cannot run."
                )

    search = RandomizedSearchCV(
        model, space, n_iter=args.n_iter, scoring="average_precision", cv=cv_splits,
        random_state=config.RANDOM_STATE, n_jobs=1, refit=True, verbose=0, error_score="raise",
    )
    search.fit(X_tr, y_tr)
    log.info("   best CV PR-AUC %.4f (%s) with %s", search.best_score_, cv_label, search.best_params_)
    params = {k: (v if isinstance(v, (int, float, str, type(None))) else str(v))
              for k, v in search.best_params_.items()}
    return search.best_estimator_, params


def _atomic_write_metadata(metadata: dict, destination: Path) -> None:
    """Atomically switch the active run pointer after its artifacts are complete."""
    temp = destination.with_suffix(".json.tmp")
    temp.write_text(json.dumps(metadata, indent=2, allow_nan=False), encoding="utf-8")
    os.replace(temp, destination)


def _train_into_run(args, run_id: str, stage_dir: Path) -> dict | None:
    reports_dir = stage_dir / "reports"
    figures_dir = reports_dir / "figures"
    reports_dir.mkdir(parents=True, exist_ok=True)
    figures_dir.mkdir(parents=True, exist_ok=True)

    # 1. Load and clean real source data.
    try:
        raw = load_dataset(args.data)
    except DatasetNotFoundError as exc:
        print(exc)
        return None
    df, cleaning_report = clean_dataset(raw)
    del raw

    # 2. EDA artifacts are run-scoped; skipped runs cannot inherit stale figures.
    eda_summary = None
    if not args.skip_eda:
        eda_summary = run_eda(df, out_dir=figures_dir, summary_path=reports_dir / "eda_summary.json")

    # 3. Split raw inputs. The complete preprocessing step is fitted inside each fold.
    train, val, test = split_data(df, strategy=args.split_strategy)
    log.info("Split (%s) -> train %s | val %s | test %s (fraud: %d / %d / %d)",
             args.split_strategy, f"{len(train):,}", f"{len(val):,}", f"{len(test):,}",
             train.Class.sum(), val.Class.sum(), test.Class.sum())
    X_tr = train[config.RAW_FEATURES].copy()
    X_val = val[config.RAW_FEATURES].copy()
    X_te = test[config.RAW_FEATURES].copy()
    y_tr, y_val, y_te = train.Class.to_numpy(), val.Class.to_numpy(), test.Class.to_numpy()
    spw = float((y_tr == 0).sum() / max((y_tr == 1).sum(), 1))

    if args.cv < 2:
        raise ValueError("--cv must be at least 2")
    if args.n_iter < 1:
        raise ValueError("--n-iter must be at least 1")
    if args.false_negative_cost <= 0 or args.false_positive_cost <= 0:
        raise ValueError("Both error-cost weights must be positive.")

    # 4. Train/tune/evaluate each model. A failed optional model does not corrupt old runs.
    keys = [k for k in available_models() if not args.models or k in args.models]
    if not keys:
        log.error("No models selected/available.")
        return None

    meta_models, val_metrics, test_metrics, test_scores = {}, {}, {}, {}
    for key in keys:
        name = config.MODEL_NAMES[key]
        log.info("Training %s ...", name)
        start = time.time()
        try:
            model, params = tune_or_fit(key, X_tr, y_tr, X_val, y_val, spw, args)
        except Exception as exc:
            log.exception("   %s failed: %s - skipping", name, exc)
            continue

        fit_secs = time.time() - start
        s_val = model.predict_proba(X_val)[:, 1]
        threshold = cost_sensitive_threshold(
            y_val, s_val, args.false_negative_cost, args.false_positive_cost
        )
        val_metrics[name] = compute_metrics(
            y_val, s_val, threshold, args.false_negative_cost, args.false_positive_cost
        )
        s_te = model.predict_proba(X_te)[:, 1]
        test_scores[key] = s_te
        test_metrics[name] = compute_metrics(
            y_te, s_te, threshold, args.false_negative_cost, args.false_positive_cost
        )
        test_metrics[name]["train_seconds"] = round(fit_secs, 1)

        joblib.dump(model, config.model_path(key, stage_dir), compress=3)
        meta_models[key] = {
            "label": name,
            "threshold": threshold,
            "best_params": params,
            "val_pr_auc": val_metrics[name]["pr_auc"],
            "train_seconds": round(fit_secs, 1),
            "threshold_objective": "validation weighted false-negative / false-positive cost",
        }
        m = test_metrics[name]
        log.info("   TEST precision %.3f | recall %.3f | F1 %.3f | PR-AUC %.4f | weighted cost %.1f (%.0fs)",
                 m["precision"], m["recall"], m["f1"], m["pr_auc"], m["weighted_error_cost"], fit_secs)

    if not meta_models:
        log.error("All models failed to train; previous active run was not changed.")
        return None

    # 5. Choose the active model using validation PR-AUC only.
    best_key = max(meta_models, key=lambda k: meta_models[k]["val_pr_auc"])
    best_name = config.MODEL_NAMES[best_key]
    best_model = joblib.load(config.model_path(best_key, stage_dir))
    best_preprocessor = best_model.named_steps["preprocessor"]
    joblib.dump(best_preprocessor, stage_dir / "preprocessor.joblib", compress=3)
    log.info("Best model (validation PR-AUC): %s", best_name)

    # 6. Model comparison and held-out reports.
    rows = []
    for key, info in meta_models.items():
        m = test_metrics[info["label"]]
        cm = m["confusion_matrix"]
        rows.append({
            "model_key": key, "model": info["label"], "precision": m["precision"], "recall": m["recall"],
            "f1": m["f1"], "roc_auc": m["roc_auc"], "pr_auc": m["pr_auc"], "accuracy": m["accuracy"],
            "threshold": m["threshold"], "tp": cm["tp"], "fp": cm["fp"], "fn": cm["fn"], "tn": cm["tn"],
            "weighted_error_cost": m["weighted_error_cost"],
            "weighted_cost_per_1000": m["weighted_cost_per_1000"],
            "val_pr_auc": info["val_pr_auc"], "train_seconds": info["train_seconds"],
            "is_best": key == best_key,
        })
    pd.DataFrame(rows).sort_values("val_pr_auc", ascending=False).to_csv(
        reports_dir / "model_comparison.csv", index=False
    )
    save_json({"test": test_metrics, "validation": val_metrics, "best_model": best_name},
              reports_dir / "metrics.json")
    save_json({config.MODEL_NAMES[k]: curve_points(y_te, s) for k, s in test_scores.items()},
              reports_dir / "curves.json")
    plot_curves({config.MODEL_NAMES[k]: s for k, s in test_scores.items()}, y_te, figures_dir)
    plot_confusion_matrices(test_metrics, figures_dir)

    # Held-out history uses model risk scores, not probability terminology.
    hist = test[config.RAW_FEATURES + [config.TARGET]].copy().reset_index(drop=True)
    hist.insert(0, "transaction_id", [f"TX-{i:06d}" for i in range(len(hist))])
    for key, score in test_scores.items():
        hist[f"risk_score_{key}"] = np.round(score, 6)
    best_threshold = meta_models[best_key]["threshold"]
    hist["risk_score"] = hist[f"risk_score_{best_key}"]
    hist["prediction"] = np.where(hist.risk_score >= best_threshold, "Suspicious", "Not flagged")
    hist["risk_level"] = [risk_level(score, best_threshold) for score in hist.risk_score]
    hist.to_csv(reports_dir / "test_predictions.csv", index=False)

    # 7. Explainability for the selected pipeline. Background is transformed using the
    # selected model's fold-local preprocessor; IF SHAP explains its displayed score.
    rng = np.random.default_rng(config.RANDOM_STATE)
    X_train_transformed = best_preprocessor.transform(X_tr)
    bg = X_train_transformed.iloc[
        rng.choice(len(X_train_transformed), min(config.SHAP_BACKGROUND_SIZE, len(X_train_transformed)), replace=False)
    ]
    joblib.dump(bg.reset_index(drop=True), stage_dir / "shap_background.joblib", compress=3)
    shap_status = "unavailable"
    try:
        explainer = FraudExplainer(best_model, best_key, bg)
        if explainer.available:
            fraud_pool = np.where(y_te == 1)[0]
            legit_pool = np.where(y_te == 0)[0]
            if best_key == "isolation_forest":
                # Permutation SHAP is model-agnostic and more expensive than TreeSHAP.
                # A balanced, bounded sample keeps full-dataset training practical.
                fraud_idx = rng.choice(fraud_pool, min(100, len(fraud_pool)), replace=False)
                legit_idx = rng.choice(legit_pool, min(100, len(legit_pool)), replace=False)
            else:
                fraud_idx = fraud_pool
                legit_idx = rng.choice(legit_pool, min(1000, len(legit_pool)), replace=False)
            sample_idx = np.concatenate([fraud_idx, legit_idx])
            sample = best_preprocessor.transform(X_te.iloc[sample_idx])
            importance = save_global_plots(explainer, sample, figures_dir, best_name)
            importance.to_csv(reports_dir / "shap_importance.csv", index=False)
            shap_status = explainer.method
            log.info("Top SHAP features: %s", ", ".join(importance.feature.head(5)))
        else:
            log.warning("SHAP unavailable for %s in this environment.", best_name)
    except Exception as exc:
        log.warning("SHAP step failed for %s: %s", best_name, exc)

    metadata = {
        "project": "FraudShield AI",
        "schema_version": 2,
        "run_id": run_id,
        "artifact_dir": f"runs/{run_id}",
        "trained_at": datetime.now().isoformat(timespec="seconds"),
        "best_model": best_key,
        "selection_metric": "validation PR-AUC",
        "models": meta_models,
        "features": best_preprocessor.feature_names,
        "dataset": {**cleaning_report, "train_rows": len(train), "val_rows": len(val),
                    "test_rows": len(test), "source": config.DATASET_URL},
        "split": {"strategy": args.split_strategy, "train_fraction": len(train) / len(df),
                  "validation_fraction": len(val) / len(df), "test_fraction": len(test) / len(df),
                  "cv": "TimeSeriesSplit" if args.split_strategy == "chronological" else "StratifiedKFold"},
        "eda": eda_summary,
        "tuning": {"enabled": not args.no_tune, "n_iter": args.n_iter, "cv_folds": args.cv,
                   "scoring": "average_precision"},
        "threshold_selection": {
            "method": "minimum weighted false-negative / false-positive cost on validation data",
            "false_negative_cost_weight": args.false_negative_cost,
            "false_positive_cost_weight": args.false_positive_cost,
            "note": "Relative cost weights supplied by the operator; not monetary calibration.",
            "f1_baseline_threshold": best_f1_threshold(y_val,
                best_model.predict_proba(X_val)[:, 1]),
        },
        "shap_method": shap_status,
        "scale_pos_weight": spw,
        "environment": {"python": platform.python_version(), "sklearn": sklearn.__version__},
    }
    return metadata


def main() -> int:
    args = parse_args()
    config.ensure_dirs()
    start = time.time()
    run_id = datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:8]
    stage_dir = config.RUNS_DIR / f".staging-{run_id}"
    final_dir = config.RUNS_DIR / run_id
    stage_dir.mkdir(parents=True, exist_ok=False)

    try:
        metadata = _train_into_run(args, run_id, stage_dir)
        if metadata is None:
            shutil.rmtree(stage_dir, ignore_errors=True)
            return 1

        # Directory rename makes all run artifacts visible together. The active pointer
        # is switched only afterwards, so a failed/aborted run cannot replace the old run.
        os.replace(stage_dir, final_dir)
        try:
            _atomic_write_metadata(metadata, config.METADATA_PATH)
        except Exception:
            # Active pointer remains the previous run; the unreferenced new run is safe.
            raise
    except Exception:
        shutil.rmtree(stage_dir, ignore_errors=True)
        raise

    log.info("Committed training run %s", run_id)
    log.info("Done in %.1f min. Launch the dashboard: streamlit run app.py", (time.time() - start) / 60)
    return 0


if __name__ == "__main__":
    sys.exit(main())
