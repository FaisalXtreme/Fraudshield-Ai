# FraudShield AI — updated bundle (trained and ready to run)

This archive is the revised project **plus a completed training run**, so the dashboard
works immediately after installation — no dataset download or retraining needed.

## What is included in this update

| Item | Location | Notes |
|---|---|---|
| Trained model run | `models/runs/20261112-091059-eac660bc/` | All 4 models, preprocessor, SHAP background, full reports and EDA figures |
| Active run pointer | `models/metadata.json` | Written atomically by `train.py`; dashboard reads this |
| Streamlit config | `.streamlit/config.toml` | `developmentMode=false` (fixes `server.port does not work when global.developmentMode is true` on non-standard installs) |
| Frozen requirements | `requirements-frozen.txt` | Exact package versions used for training — use this for a bit-compatible environment |

**Not included:** `data/creditcard.csv` (144 MB). It is only needed for **retraining**;
the dashboard and all artifacts run without it. Download it from
[Kaggle](https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud) and place it at
`data/creditcard.csv` if you want to retrain (see `data/README.md`).

## Run it locally (2 steps)

```bash
cd FraudShield-AI
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt                     # or requirements-frozen.txt for exact versions
streamlit run app.py
```

Then open `http://localhost:8501`. The sidebar shows **Active model: XGBoost** —
if you see the setup screen instead, the `models/` folder was moved or renamed;
keep the project structure exactly as shipped.

Training results are on the **Model Performance** page. Test metrics below are from the
untouched latest-20% chronological holdout (56,746 transactions, 74 frauds); the active
model was selected by **validation** PR-AUC.

| Model | Precision | Recall | F1 | ROC-AUC | PR-AUC | Threshold |
|---|---|---|---|---|---|---|
| **XGBoost (active)** | 0.873 | 0.743 | 0.803 | 0.978 | 0.797 | 0.949 |
| Random Forest | 0.740 | 0.770 | 0.755 | 0.979 | 0.816 | 0.271 |
| Logistic Regression | 0.627 | 0.703 | 0.662 | 0.984 | 0.732 | 1.000 |
| Isolation Forest | 0.000 | 0.000 | 0.000 | 0.948 | 0.040 | — (unsupervised) |

The Isolation Forest is an unsupervised baseline: its anomaly scores rank transactions
but, at the cost-optimal threshold on this data, it flags nothing — expected for this
model family, not a bug.

## Retraining (optional)

```bash
python train.py            # full run with tuning (needs data/creditcard.csv)
python train.py --no-tune  # ~4 minutes, reproduces the bundled run
pytest -q                  # 20 tests, all passing on synthetic data
```

Environment used for the bundled run: Python 3.12.16, scikit-learn 1.5.2, XGBoost 2.1.3,
streamlit 1.67.0 (full list in `requirements-frozen.txt`). Model artifacts should be
loaded with a matching scikit-learn version.
