"""Unit and smoke tests for FraudShield AI (all test data is synthetic)."""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from src import config
from src.data_loader import DatasetNotFoundError, clean_dataset, load_dataset, validate_schema
from src.evaluate import best_f1_threshold, compute_metrics, cost_sensitive_threshold
from src.explain import FraudExplainer, top_factors
from src.models import (
    IsolationForestDetector, build_model, build_training_pipeline, final_estimator,
)
from src.predict import risk_level
from src.preprocessing import FraudPreprocessor, split_data


@pytest.fixture(scope="module")
def frame():
    rng = np.random.default_rng(0)
    n = 3000
    y = (rng.random(n) < 0.05).astype(int)
    v = rng.normal(size=(n, 28))
    v[y == 1, :3] += 3
    df = pd.DataFrame(v, columns=config.PCA_FEATURES)
    df.insert(0, "Time", np.sort(rng.uniform(0, 172800, n)))
    df["Amount"] = rng.lognormal(3, 1, n)
    df["Class"] = y
    return df


def test_missing_dataset_raises(tmp_path):
    with pytest.raises(DatasetNotFoundError):
        load_dataset(tmp_path / "nope.csv")


def test_schema_validation(frame):
    validate_schema(frame)
    with pytest.raises(ValueError):
        validate_schema(frame.drop(columns=["V5"]))


def test_clean_removes_duplicates(frame):
    dup = pd.concat([frame, frame.iloc[:10]])
    cleaned, report = clean_dataset(dup)
    assert report["duplicate_rows_dropped"] == 10
    assert len(cleaned) == len(frame)


def test_clean_rejects_non_numeric_non_finite_and_negative_time(frame):
    damaged = frame.copy()
    damaged.loc[damaged.index[0], "V1"] = np.inf
    damaged["V2"] = damaged["V2"].astype(object)
    damaged.loc[damaged.index[1], "V2"] = "not-a-number"
    damaged.loc[damaged.index[2], "Time"] = -1
    cleaned, report = clean_dataset(damaged)
    assert len(cleaned) == len(frame) - 3
    assert report["rows_non_finite_dropped"] == 1
    assert report["rows_with_missing_or_non_numeric_dropped"] == 1
    assert report["negative_time_dropped"] == 1


def test_chronological_split_is_ordered_and_disjoint(frame):
    tr, va, te = split_data(frame, strategy="chronological")
    assert len(tr) + len(va) + len(te) == len(frame)
    assert tr.Time.max() <= va.Time.min()
    assert va.Time.max() <= te.Time.min()
    for part in (tr, va, te):
        assert set(part.Class.unique()) == {0, 1}


def test_chronological_split_never_separates_equal_timestamps(frame):
    repeated = frame.copy()
    repeated["Time"] = np.floor(repeated["Time"] / 3600.0)
    tr, va, te = split_data(repeated, strategy="chronological")
    combined = pd.concat([
        tr.assign(_partition="train"),
        va.assign(_partition="validation"),
        te.assign(_partition="test"),
    ])
    assert combined.groupby("Time")._partition.nunique().max() == 1


def test_chronological_split_requires_enough_distinct_times(frame):
    tiny = frame.copy()
    tiny["Time"] = np.tile([0.0, 1.0], len(tiny) // 2 + 1)[:len(tiny)]
    with pytest.raises(ValueError, match="three distinct Time values"):
        split_data(tiny, strategy="chronological")


def test_stratified_split_is_stratified(frame):
    tr, va, te = split_data(frame, strategy="stratified")
    for part in (tr, va, te):
        assert abs(part.Class.mean() - frame.Class.mean()) < 0.02


def test_preprocessor_cyclical_features_and_validation(frame):
    pre = FraudPreprocessor().fit(frame)
    X = pre.transform(frame)
    assert list(X.columns) == config.MODEL_FEATURES
    assert "TimeSin" in X and "TimeCos" in X
    assert not X.isna().any().any()

    # 23:59 and 00:01 are close in the cyclical representation.
    edge = pd.DataFrame({c: [0.0, 0.0] for c in config.RAW_FEATURES})
    edge["Time"] = [86340.0, 60.0]
    edge["Amount"] = [10.0, 10.0]
    cyc = pre.transform(edge)[["TimeSin", "TimeCos"]].to_numpy()
    assert np.linalg.norm(cyc[0] - cyc[1]) < 0.02

    bad = frame.head(1).copy()
    bad["Amount"] = -5
    with pytest.raises(ValueError):
        pre.transform(bad)
    bad = frame.head(1).copy()
    bad["V1"] = np.inf
    with pytest.raises(ValueError, match="non-finite"):
        pre.transform(bad)
    with pytest.raises(ValueError):
        pre.transform(frame.drop(columns=["Amount"]).head(1))


@pytest.mark.parametrize("key", ["logistic_regression", "random_forest", "isolation_forest"])
def test_models_train_and_score(frame, key):
    pre = FraudPreprocessor().fit(frame)
    X, y = pre.transform(frame), frame.Class.to_numpy()
    model = build_model(key, scale_pos_weight=19)
    model.fit(X, y)
    score = model.predict_proba(X)[:, 1]
    assert score.shape == (len(X),) and np.isfinite(score).all()
    assert ((score >= 0) & (score <= 1)).all()
    metrics = compute_metrics(y, score, best_f1_threshold(y, score))
    assert metrics["roc_auc"] > 0.7
    assert set(metrics["confusion_matrix"]) == {"tn", "fp", "fn", "tp"}


def test_full_pipeline_fits_preprocessing_inside_estimator(frame):
    train, validation, _ = split_data(frame, strategy="stratified")
    X_train, X_val = train[config.RAW_FEATURES], validation[config.RAW_FEATURES]
    model = build_training_pipeline("logistic_regression")
    model.fit(X_train, train.Class)
    scores = model.predict_proba(X_val)[:, 1]
    assert scores.shape == (len(X_val),)
    assert list(model.named_steps["preprocessor"].feature_names) == config.MODEL_FEATURES
    assert final_estimator(model) is model.named_steps["clf"]


def test_isolation_forest_full_pipeline(frame):
    train, validation, _ = split_data(frame, strategy="stratified")
    pipeline = build_training_pipeline("isolation_forest", isolation_params={"n_estimators": 30})
    pipeline.fit(train[config.RAW_FEATURES], train.Class)
    scores = pipeline.predict_proba(validation[config.RAW_FEATURES])[:, 1]
    assert scores.shape == (len(validation),)
    assert np.isfinite(scores).all()
    assert final_estimator(pipeline) is pipeline.named_steps["detector"]


def test_cost_sensitive_threshold_and_metrics():
    y = np.array([0, 0, 0, 1, 1])
    scores = np.array([0.05, 0.2, 0.7, 0.4, 0.8])
    threshold = cost_sensitive_threshold(y, scores, false_negative_cost=10, false_positive_cost=1)
    assert 0 <= threshold <= 1
    metrics = compute_metrics(y, scores, threshold, 10, 1)
    assert "weighted_error_cost" in metrics
    assert metrics["weighted_cost_per_1000"] >= 0
    with pytest.raises(ValueError):
        cost_sensitive_threshold(y, scores, 0, 1)

    # When review/false-positive cost dominates, selecting no positive predictions
    # must be a candidate rather than an unreachable operating point.
    no_flag = cost_sensitive_threshold(np.array([0, 0, 1]), np.array([0.9, 0.8, 0.1]), 1, 100)
    assert no_flag > 0.9


def test_metrics_match_hand_computation():
    y = np.array([0, 0, 1, 1])
    score = np.array([0.1, 0.6, 0.4, 0.9])
    metrics = compute_metrics(y, score, 0.5)
    assert metrics["confusion_matrix"] == {"tn": 1, "fp": 1, "fn": 1, "tp": 1}
    assert metrics["precision"] == 0.5 and metrics["recall"] == 0.5


def test_linear_explanation_is_additive(frame):
    pre = FraudPreprocessor().fit(frame)
    X = pre.transform(frame)
    model = build_model("logistic_regression").fit(X, frame.Class.to_numpy())
    explainer = FraudExplainer(model, "logistic_regression", X.sample(200, random_state=0))
    vals, base = explainer.explain(X.head(5))
    logit = model.decision_function(X.head(5))
    np.testing.assert_allclose(vals.sum(axis=1) + base, logit, atol=1e-4)
    factors = top_factors(vals[0], explainer.feature_names, frame.iloc[0], k=3)
    assert len(factors) == 3 and factors[0]["direction"] in {"increases", "decreases"}


def test_isolation_forest_explains_its_displayed_score(frame):
    pytest.importorskip("shap")
    pre = FraudPreprocessor().fit(frame)
    X = pre.transform(frame)
    detector = IsolationForestDetector(n_estimators=50).fit(X)
    assert detector.predict_proba(X).shape == (len(X), 2)
    assert final_estimator(detector) is detector
    explainer = FraudExplainer(detector, "isolation_forest", X.sample(60, random_state=0))
    assert explainer.available
    vals, base = explainer.explain(X.head(3))
    expected = detector.anomaly_score(X.head(3))
    np.testing.assert_allclose(vals.sum(axis=1) + base, expected, atol=2e-3)
    assert "normalized anomaly score" in explainer.units


def test_risk_levels():
    assert risk_level(0.9, 0.5) == "High"
    assert risk_level(0.3, 0.5) == "Medium"
    assert risk_level(0.1, 0.5) == "Low"


@pytest.mark.skipif(not __import__("src.models", fromlist=["HAS_XGB"]).HAS_XGB, reason="xgboost not installed")
def test_xgboost_and_shap(frame):
    pre = FraudPreprocessor().fit(frame)
    X, y = pre.transform(frame), frame.Class.to_numpy()
    model = build_model("xgboost", scale_pos_weight=19)
    model.set_params(n_estimators=50)
    model.fit(X, y)
    explainer = FraudExplainer(model, "xgboost", X.sample(100, random_state=0))
    vals, base = explainer.explain(X.head(5))
    margin = model.predict(X.head(5), output_margin=True)
    np.testing.assert_allclose(vals.sum(axis=1) + base, margin, atol=1e-3)
