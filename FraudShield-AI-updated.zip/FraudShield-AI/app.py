"""FraudShield AI - Streamlit dashboard entry point.

Run from the project root:
    streamlit run app.py
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import streamlit as st  # noqa: E402

st.set_page_config(page_title="FraudShield AI", page_icon="🛡️", layout="wide",
                   initial_sidebar_state="expanded")

from dashboard import data  # noqa: E402
from dashboard.theme import MUTED, apply_css  # noqa: E402
from dashboard.views import about, explainability, history, overview, performance, predict  # noqa: E402
from src import config  # noqa: E402

PAGES = {
    "Overview": overview.render,
    "Analyze Transaction": predict.render,
    "Transaction History": history.render,
    "Model Performance": performance.render,
    "Explainable AI": explainability.render,
    "Data & Methodology": about.render,
}


def setup_screen() -> None:
    st.title("FraudShield AI")
    st.error("No trained models were found, so the dashboard has nothing real to show yet.")
    has_data = config.DATASET_PATH.exists()
    st.markdown(f"""
**Step 1 - dataset** {'✅ found' if has_data else '❌ missing'}
Download `creditcard.csv` from [Kaggle]({config.DATASET_URL}) and place it at `data/creditcard.csv`.

**Step 2 - train**
```bash
python train.py            # full run with tuning
python train.py --no-tune  # quicker first run
```

**Step 3 - refresh this page.**
""")


def main() -> None:
    apply_css()
    with st.sidebar:
        st.markdown("## 🛡️ FraudShield AI")
        st.markdown(f"<span style='color:{MUTED};font-size:.85rem'>Intelligent financial fraud "
                    "detection</span>", unsafe_allow_html=True)
        st.write("")

    if not data.artifacts_ready():
        setup_screen()
        return

    try:
        meta = data.metadata(data.version())
    except Exception as exc:
        st.error(f"Could not read model metadata ({exc}). Re-run `python train.py`.")
        return

    with st.sidebar:
        page = st.radio("Navigation", list(PAGES), label_visibility="collapsed")
        st.divider()
        best = meta["best_model"]
        st.caption(f"**Active model:** {config.MODEL_NAMES[best]}")
        st.caption(f"**Threshold:** {meta['models'][best]['threshold']:.3f}")
        st.caption(f"**Trained:** {meta['trained_at'].replace('T', ' ')}")
        st.caption("Scores are risk estimates, not fraud determinations.")

    try:
        PAGES[page]()
    except Exception as exc:  # keep the app usable if one page fails
        st.error(f"This page hit an error: {exc}")
        st.caption("If you recently changed code or retrained, try re-running `python train.py`.")
        with st.expander("Details"):
            st.exception(exc)


main()
