"""Loading and validating the Kaggle Credit Card Fraud dataset."""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from . import config
from .utils import get_logger

log = get_logger()


class DatasetNotFoundError(FileNotFoundError):
    """Raised when data/creditcard.csv is missing."""


DOWNLOAD_HELP = f"""
Dataset not found at: {config.DATASET_PATH}

FraudShield AI trains only on the real Kaggle dataset. Download it with ONE of:

  A) Browser
     1. Open {config.DATASET_URL}
     2. Click "Download" (free Kaggle account needed) and unzip.
     3. Move creditcard.csv into the  data/  folder of this project.

  B) Kaggle CLI
     pip install kaggle
     # put kaggle.json (Kaggle > Settings > API > Create New Token) in
     #   Windows: C:\\Users\\<you>\\.kaggle\\kaggle.json
     #   macOS/Linux: ~/.kaggle/kaggle.json
     kaggle datasets download -d {config.KAGGLE_SLUG} -p data --unzip

Then run:  python train.py
"""


def load_dataset(path: Path | str = config.DATASET_PATH) -> pd.DataFrame:
    """Load the CSV and validate its schema. Raises with download instructions if missing."""
    path = Path(path)
    if not path.exists():
        raise DatasetNotFoundError(DOWNLOAD_HELP)

    log.info("Loading dataset from %s", path)
    try:
        df = pd.read_csv(path)
    except Exception as exc:  # corrupted / partial download
        raise ValueError(f"Could not read {path}: {exc}. Re-download the file.") from exc

    validate_schema(df)
    log.info("Loaded %s rows x %s columns", f"{len(df):,}", df.shape[1])
    return df


def validate_schema(df: pd.DataFrame) -> None:
    missing = [c for c in config.REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(
            f"Dataset is missing columns {missing}. Expected the Kaggle 'creditcard.csv' "
            f"with columns Time, V1..V28, Amount, Class."
        )
    labels = set(pd.unique(df[config.TARGET].dropna()))
    if not labels.issubset({0, 1}):
        raise ValueError(f"'Class' must contain only 0/1, found {sorted(labels)}")
    if len(labels) < 2:
        raise ValueError("Dataset contains only one class; cannot train a classifier.")


def clean_dataset(df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Drop rows with missing values and exact duplicates. Returns cleaned df + a report."""
    report = {"rows_raw": int(len(df))}
    df = df[config.REQUIRED_COLUMNS].copy()

    # CSV imports can silently turn malformed numeric cells into object/string data.
    # Coerce the model inputs once here so chronological sorting is truly numeric.
    for column in config.RAW_FEATURES:
        df[column] = pd.to_numeric(df[column], errors="coerce")

    n_missing = int(df.isna().any(axis=1).sum())
    df = df.dropna().copy()
    report["rows_with_missing_or_non_numeric_dropped"] = n_missing

    numeric = df[config.RAW_FEATURES].to_numpy(dtype=float)
    non_finite = ~np.isfinite(numeric).all(axis=1)
    n_non_finite = int(non_finite.sum())
    df = df.loc[~non_finite].copy()
    report["rows_non_finite_dropped"] = n_non_finite

    n_dup = int(df.duplicated().sum())
    df = df.drop_duplicates().reset_index(drop=True)
    report["duplicate_rows_dropped"] = n_dup

    n_neg_amount = int((df["Amount"] < 0).sum())
    df = df[df["Amount"] >= 0].copy()
    report["negative_amount_dropped"] = n_neg_amount

    n_neg_time = int((df["Time"] < 0).sum())
    df = df[df["Time"] >= 0].reset_index(drop=True)
    report["negative_time_dropped"] = n_neg_time

    if df[config.TARGET].nunique() < 2:
        raise ValueError("Cleaning removed all examples of one class; cannot train a classifier.")

    df[config.TARGET] = df[config.TARGET].astype(int)
    report["rows_clean"] = int(len(df))
    report["fraud_count"] = int(df[config.TARGET].sum())
    report["legit_count"] = int((df[config.TARGET] == 0).sum())
    report["fraud_rate"] = float(df[config.TARGET].mean())
    log.info(
        "Cleaning: %d missing/non-numeric, %d non-finite, %d duplicates removed -> "
        "%s rows (%d fraud, %.3f%%)",
        n_missing, n_non_finite, n_dup, f"{len(df):,}",
        report["fraud_count"], 100 * report["fraud_rate"],
    )
    return df, report
