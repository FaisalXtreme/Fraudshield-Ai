"""Feature preprocessing and chronological / stratified data splitting."""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import RobustScaler

from . import config


class FraudPreprocessor(BaseEstimator, TransformerMixin):
    """Fold-local transformer for raw transaction columns.

    Amount is log-transformed and robust-scaled. The elapsed-seconds Time field is
    encoded as a continuous daily-cycle sine/cosine pair. PCA components pass through.
    It is intentionally a sklearn transformer so it can live inside CV pipelines;
    every fold therefore fits its own scaling statistics using only that fold's train rows.
    """

    def __init__(self) -> None:
        self.amount_scaler = RobustScaler()
        self.feature_names = list(config.MODEL_FEATURES)
        self.fitted = False

    @staticmethod
    def _validate(df: pd.DataFrame) -> pd.DataFrame:
        if not isinstance(df, pd.DataFrame):
            df = pd.DataFrame(df, columns=config.RAW_FEATURES)
        missing = [c for c in config.RAW_FEATURES if c not in df.columns]
        if missing:
            raise ValueError(f"Input is missing required columns: {missing}")
        x = df[config.RAW_FEATURES].apply(pd.to_numeric, errors="coerce")
        if x.isna().any().any():
            bad = x.columns[x.isna().any()].tolist()
            raise ValueError(f"Non-numeric or missing values in columns: {bad}")
        values = x.to_numpy(dtype=float)
        if not np.isfinite(values).all():
            bad = x.columns[~np.isfinite(values).all(axis=0)].tolist()
            raise ValueError(f"Input contains infinite or non-finite values in columns: {bad}")
        if (x["Amount"] < 0).any():
            raise ValueError("Amount must be >= 0")
        if (x["Time"] < 0).any():
            raise ValueError("Time must be >= 0")
        return x

    @staticmethod
    def daily_phase(time_seconds: pd.Series | np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        seconds = np.asarray(time_seconds, dtype=float) % 86400.0
        angle = 2.0 * np.pi * seconds / 86400.0
        return np.sin(angle), np.cos(angle)

    def fit(self, X: pd.DataFrame, y=None) -> "FraudPreprocessor":
        x = self._validate(X)
        self.amount_scaler.fit(np.log1p(x[["Amount"]].to_numpy()))
        self.fitted = True
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        if not self.fitted:
            raise RuntimeError("Preprocessor must be fitted before transform().")
        x = self._validate(X)
        out = x[config.PCA_FEATURES].astype(float).copy()
        out["Amount"] = self.amount_scaler.transform(np.log1p(x[["Amount"]].to_numpy())).ravel()
        out["TimeSin"], out["TimeCos"] = self.daily_phase(x["Time"])
        return out[self.feature_names].reset_index(drop=True)

    def fit_transform(self, X: pd.DataFrame, y=None, **fit_params) -> pd.DataFrame:
        return self.fit(X, y).transform(X)

    def get_feature_names_out(self, input_features=None):
        return np.asarray(self.feature_names, dtype=object)


def split_data(
    df: pd.DataFrame,
    seed: int = config.RANDOM_STATE,
    strategy: str = "chronological",
):
    """Return train / validation / test splits.

    chronological: sort by Time and reserve the latest 20% for test and the preceding
    16% for validation. This is the default because the application targets future fraud.
    stratified: random stratified split retained as a benchmark / fallback for small samples.
    """
    if strategy == "chronological":
        ordered = df.sort_values("Time", kind="stable").reset_index(drop=True)
        n = len(ordered)
        target_train = int(n * (1.0 - config.TEST_SIZE) * (1.0 - config.VAL_SIZE))
        target_train_val = int(n * (1.0 - config.TEST_SIZE))
        # Keep rows sharing an identical timestamp together; do not split one second
        # of transactions across two different evaluation periods.
        unique_times, group_counts = np.unique(ordered["Time"].to_numpy(), return_counts=True)
        if len(unique_times) < 3:
            raise ValueError(
                "Chronological splitting requires at least three distinct Time values. "
                "Use a larger dataset or --split-strategy stratified for a random benchmark."
            )
        cumulative = np.cumsum(group_counts)
        train_group_end = min(int(np.searchsorted(cumulative, target_train, side="left")) + 1,
                              len(unique_times) - 2)
        val_group_end = min(int(np.searchsorted(cumulative, target_train_val, side="left")) + 1,
                            len(unique_times) - 1)
        val_group_end = max(val_group_end, train_group_end + 1)
        train_cut = unique_times[train_group_end - 1]
        val_cut = unique_times[val_group_end - 1]
        train = ordered[ordered["Time"] <= train_cut].copy()
        val = ordered[(ordered["Time"] > train_cut) & (ordered["Time"] <= val_cut)].copy()
        test = ordered[ordered["Time"] > val_cut].copy()
        if train.empty or val.empty or test.empty:
            raise ValueError(
                "Chronological split produced an empty partition. Use a larger dataset "
                "or --split-strategy stratified for a random benchmark."
            )
        for label, part in (("training", train), ("validation", val), ("test", test)):
            if part[config.TARGET].nunique() < 2:
                raise ValueError(
                    f"Chronological {label} split contains only one class. The dataset may be too small "
                    "or fraud may be concentrated outside this period. Use --split-strategy stratified "
                    "for a random benchmark, and inspect the time distribution before deployment."
                )
        return train.reset_index(drop=True), val.reset_index(drop=True), test.reset_index(drop=True)

    if strategy != "stratified":
        raise ValueError("strategy must be 'chronological' or 'stratified'")
    train_val, test = train_test_split(
        df, test_size=config.TEST_SIZE, stratify=df[config.TARGET], random_state=seed
    )
    train, val = train_test_split(
        train_val, test_size=config.VAL_SIZE, stratify=train_val[config.TARGET], random_state=seed
    )
    return train.reset_index(drop=True), val.reset_index(drop=True), test.reset_index(drop=True)
