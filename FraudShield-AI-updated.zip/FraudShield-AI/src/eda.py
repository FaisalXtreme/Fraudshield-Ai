"""Exploratory Data Analysis: summary statistics and saved figures (reports/figures)."""
from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

from . import config
from .utils import get_logger, save_json

log = get_logger()

NAVY = "#0B1220"
PANEL = "#111A2E"
TEXT = "#E2E8F0"
MUTED = "#94A3B8"
BLUE = "#3B82F6"
RED = "#F43F5E"
PALETTE = {0: BLUE, 1: RED}


def set_style() -> None:
    sns.set_theme(style="darkgrid")
    plt.rcParams.update({
        "figure.facecolor": NAVY, "axes.facecolor": PANEL, "savefig.facecolor": NAVY,
        "axes.edgecolor": "#1E293B", "grid.color": "#1E293B", "text.color": TEXT,
        "axes.labelcolor": TEXT, "xtick.color": MUTED, "ytick.color": MUTED,
        "axes.titleweight": "bold", "axes.titlesize": 13, "font.size": 10,
        "legend.facecolor": PANEL, "legend.edgecolor": "#1E293B",
    })


def _save(fig, name: str, out_dir: Path) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / name
    fig.tight_layout()
    fig.savefig(path, dpi=130)
    plt.close(fig)
    return path


def summarize(df: pd.DataFrame) -> dict:
    fraud = df[df[config.TARGET] == 1]
    legit = df[df[config.TARGET] == 0]
    corr = df[[*config.PCA_FEATURES, "Amount", "Time", config.TARGET]].corr()[config.TARGET].drop(config.TARGET)
    top = corr.abs().sort_values(ascending=False).head(10)
    return {
        "n_transactions": int(len(df)),
        "n_fraud": int(len(fraud)),
        "n_legit": int(len(legit)),
        "fraud_rate_pct": round(100 * len(fraud) / len(df), 4),
        "imbalance_ratio": f"1 : {len(legit) / max(len(fraud), 1):.0f}",
        "amount_mean_fraud": float(fraud["Amount"].mean()),
        "amount_mean_legit": float(legit["Amount"].mean()),
        "amount_median_fraud": float(fraud["Amount"].median()),
        "amount_median_legit": float(legit["Amount"].median()),
        "amount_max": float(df["Amount"].max()),
        "time_span_hours": float(df["Time"].max() / 3600),
        "top_correlated_features": {k: round(float(corr[k]), 4) for k in top.index},
    }


def run_eda(df: pd.DataFrame, out_dir: Path = config.FIGURES_DIR, summary_path: Path = config.EDA_SUMMARY_PATH) -> dict:
    """Create EDA figures and return summary stats (also saved to reports/eda_summary.json)."""
    set_style()
    summary = summarize(df)
    label = df[config.TARGET].map({0: "Legitimate", 1: "Fraud"})

    # 1. Class distribution
    fig, ax = plt.subplots(figsize=(6, 4))
    counts = df[config.TARGET].value_counts().sort_index()
    bars = ax.bar(["Legitimate", "Fraud"], counts.values, color=[BLUE, RED])
    ax.set_yscale("log")
    ax.set_title("Class distribution (log scale)")
    ax.set_ylabel("Transactions")
    for b, v in zip(bars, counts.values):
        ax.text(b.get_x() + b.get_width() / 2, v, f"{v:,}\n({100 * v / len(df):.3f}%)",
                ha="center", va="bottom", color=TEXT, fontsize=9)
    _save(fig, "01_class_distribution.png", out_dir)

    # 2. Amount distribution by class
    fig, ax = plt.subplots(figsize=(7, 4))
    for cls, name in [(0, "Legitimate"), (1, "Fraud")]:
        sns.kdeplot(np.log1p(df.loc[df[config.TARGET] == cls, "Amount"]), ax=ax, fill=True,
                    color=PALETTE[cls], label=name, common_norm=False, alpha=0.35, warn_singular=False)
    ax.set_title("Transaction amount by class")
    ax.set_xlabel("log(1 + Amount)")
    ax.legend()
    _save(fig, "02_amount_by_class.png", out_dir)

    # 3. Elapsed-time daily-cycle pattern
    fig, ax = plt.subplots(figsize=(7, 4))
    hours = (df["Time"] % 86400 // 3600).astype(int)
    rate = df.groupby(hours)[config.TARGET].mean() * 100
    ax.bar(rate.index, rate.values, color=BLUE)
    ax.set_title("Fraud rate by elapsed-time cycle")
    ax.set_xlabel("Elapsed-time phase (hour-equivalent; not wall-clock time)")
    ax.set_ylabel("Fraud rate (%)")
    _save(fig, "03_fraud_rate_by_hour.png", out_dir)

    # 4. Correlation of each feature with the label
    fig, ax = plt.subplots(figsize=(7, 7))
    corr = df[[*config.PCA_FEATURES, "Amount", "Time", config.TARGET]].corr()[config.TARGET].drop(config.TARGET)
    corr = corr.sort_values()
    ax.barh(corr.index, corr.values, color=[RED if v > 0 else BLUE for v in corr.values])
    ax.set_title("Correlation with fraud label")
    ax.set_xlabel("Pearson correlation")
    _save(fig, "04_feature_correlation_with_class.png", out_dir)

    # 5. Distribution of the most discriminative features
    top4 = list(summary["top_correlated_features"].keys())[:4]
    fig, axes = plt.subplots(2, 2, figsize=(9, 6))
    for ax, feat in zip(axes.ravel(), top4):
        sns.boxplot(x=label, y=df[feat], ax=ax, hue=label, legend=False, fliersize=1,
                    palette={"Legitimate": BLUE, "Fraud": RED})
        ax.set_title(feat)
        ax.set_xlabel("")
    _save(fig, "05_top_feature_distributions.png", out_dir)

    # 6. Correlation heatmap (fraud-only shows structure hidden in the whole set)
    fig, ax = plt.subplots(figsize=(9, 7.5))
    sns.heatmap(df[df[config.TARGET] == 1][[*config.PCA_FEATURES, "Amount"]].corr(),
                cmap="coolwarm", center=0, ax=ax, cbar_kws={"shrink": 0.7})
    ax.set_title("Feature correlation among fraudulent transactions")
    _save(fig, "06_fraud_correlation_heatmap.png", out_dir)

    save_json(summary, summary_path)
    log.info("EDA figures saved to %s", out_dir)
    return summary
