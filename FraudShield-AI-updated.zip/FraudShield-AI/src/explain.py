"""SHAP explanations in the units of each model's actual risk-scoring function.

Positive SHAP values increase the model's fraud-risk/anomaly score. Isolation Forest
uses model-agnostic permutation SHAP against the same normalized anomaly_score() shown
in the dashboard; its explanations therefore add up to that displayed score.
"""
from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from . import config
from .eda import BLUE, RED, set_style
from .models import IsolationForestDetector, final_estimator
from .utils import get_logger, is_available

log = get_logger()
HAS_SHAP = is_available("shap")


def _class1(values, expected):
    """Normalize classifier SHAP outputs to (n, f) values + scalar class-1 base."""
    if isinstance(values, list):
        values = values[1] if len(values) > 1 else values[0]
    values = np.asarray(values)
    if values.ndim == 3:
        values = values[:, :, 1]
    exp = np.atleast_1d(np.asarray(expected, dtype=float))
    base = float(exp[1] if exp.size > 1 else exp[0])
    return values, base


class FraudExplainer:
    def __init__(self, model, model_key: str, background: pd.DataFrame):
        self.model = model
        self.key = model_key
        self.est = final_estimator(model)
        self.background = background.copy()
        self.feature_names = list(background.columns)
        self.method = None
        self.units = ""
        self._explainer = None
        self._init()

    def _isolation_score(self, values):
        if isinstance(values, pd.DataFrame):
            frame = values
        else:
            frame = pd.DataFrame(np.asarray(values), columns=self.feature_names)
        return self.est.anomaly_score(frame[self.feature_names])

    def _init(self) -> None:
        if not HAS_SHAP:
            if self.key == "xgboost":
                self.method, self.units = "xgb_native", "log-odds score"
            elif self.key == "logistic_regression":
                self.method, self.units = "linear_exact", "log-odds score"
            return

        import shap
        try:
            if self.key == "isolation_forest":
                # Explain the normalized score function used by prediction, not the raw
                # IsolationForest path-length output (different units and baseline).
                masker = shap.maskers.Independent(self.background)
                self._explainer = shap.PermutationExplainer(self._isolation_score, masker)
                self.units = "normalized anomaly score (0-1)"
            elif self.key == "logistic_regression":
                self._explainer = shap.LinearExplainer(self.est, self.background)
                self.units = "log-odds score"
            else:
                self._explainer = shap.TreeExplainer(self.est)
                self.units = "model score (0-1)" if self.key == "random_forest" else "log-odds score"
            self.method = "shap"
            return
        except Exception as exc:
            log.warning("SHAP explainer failed for %s (%s); trying fallback", self.key, exc)

        if self.key == "xgboost":
            self.method, self.units = "xgb_native", "log-odds score"
        elif self.key == "logistic_regression":
            self.method, self.units = "linear_exact", "log-odds score"
        else:
            self.method = None

    @property
    def available(self) -> bool:
        return self.method is not None

    def explain(self, X: pd.DataFrame) -> tuple[np.ndarray, float]:
        """Return contributions (n_samples, n_features) and their scalar baseline."""
        if not self.available:
            raise RuntimeError("Explanations are unavailable for this model/environment.")
        X = X[self.feature_names]

        if self.method == "shap":
            if self.key == "isolation_forest":
                explanation = self._explainer(X, max_evals=2 * len(self.feature_names) + 1, silent=True)
                vals = np.asarray(explanation.values, dtype=float)
                base_values = np.asarray(explanation.base_values, dtype=float)
                base = float(base_values.reshape(-1)[0])
                if vals.ndim == 3:
                    vals = vals[:, :, 0]
                return vals, base
            if self.key == "logistic_regression":
                vals = self._explainer.shap_values(X)
                return _class1(vals, self._explainer.expected_value)
            vals = self._explainer.shap_values(X, check_additivity=False)
            return _class1(vals, self._explainer.expected_value)

        if self.method == "xgb_native":
            import xgboost as xgb
            contrib = self.est.get_booster().predict(xgb.DMatrix(X), pred_contribs=True)
            return contrib[:, :-1], float(contrib[0, -1])

        if self.method == "linear_exact":
            coef = self.est.coef_.ravel()
            mean = self.background.mean().to_numpy()
            vals = (X.to_numpy() - mean) * coef
            base = float(self.est.intercept_[0] + mean @ coef)
            return vals, base

        raise RuntimeError("No explanation method available")

    def global_importance(self, X: pd.DataFrame) -> pd.DataFrame:
        vals, _ = self.explain(X)
        self._last_explanation_sample = X.copy()
        self._last_explanation_values = vals
        return (pd.DataFrame({
            "feature": self.feature_names,
            "mean_abs_shap": np.abs(vals).mean(axis=0),
            "mean_shap": vals.mean(axis=0),
        }).sort_values("mean_abs_shap", ascending=False).reset_index(drop=True))


def top_factors(shap_row: np.ndarray, feature_names: list[str], raw_row: pd.Series | None = None,
                k: int = 6) -> list[dict]:
    order = np.argsort(-np.abs(shap_row))[:k]
    out = []
    for i in order:
        feature = feature_names[i]
        raw_val = None
        if raw_row is not None:
            if feature == "Amount":
                raw_val = float(raw_row["Amount"])
            elif feature in raw_row and feature not in {"TimeSin", "TimeCos"}:
                raw_val = float(raw_row[feature])
        if feature == "TimeSin":
            display_name = "Elapsed-time daily cycle (sine)"
        elif feature == "TimeCos":
            display_name = "Elapsed-time daily cycle (cosine)"
        else:
            display_name = feature
        out.append({
            "feature": feature,
            "display_name": display_name,
            "shap_value": float(shap_row[i]),
            "direction": "increases" if shap_row[i] > 0 else "decreases",
            "value": raw_val,
        })
    return out


def save_global_plots(explainer: FraudExplainer, X_sample: pd.DataFrame, out_dir: Path,
                      model_label: str) -> pd.DataFrame:
    imp = explainer.global_importance(X_sample)
    set_style()
    top = imp.head(15).iloc[::-1]
    fig, ax = plt.subplots(figsize=(7, 6))
    ax.barh(top["feature"], top["mean_abs_shap"],
            color=[RED if v > 0 else BLUE for v in top["mean_shap"]])
    ax.set_title(f"Global feature importance - {model_label}\n(mean |SHAP|; red = on average raises risk)")
    ax.set_xlabel(f"mean |SHAP value| ({explainer.units})")
    fig.tight_layout()
    out_dir.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_dir / "09_shap_importance.png", dpi=130)
    plt.close(fig)

    if explainer.method == "shap":
        try:
            import shap
            if (getattr(explainer, "_last_explanation_sample", None) is not None
                    and explainer._last_explanation_sample.equals(X_sample)):
                vals = explainer._last_explanation_values
            else:
                vals, _ = explainer.explain(X_sample)
            plt.figure()
            shap.summary_plot(vals, X_sample, show=False, max_display=15)
            plt.title(f"SHAP summary - {model_label}")
            plt.tight_layout()
            plt.savefig(out_dir / "10_shap_summary.png", dpi=130, facecolor="white")
            plt.close("all")
        except Exception as exc:
            log.warning("Could not create SHAP beeswarm plot: %s", exc)
    return imp
