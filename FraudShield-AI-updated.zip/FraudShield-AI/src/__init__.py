"""FraudShield AI core package."""

__version__ = "1.1.0"
