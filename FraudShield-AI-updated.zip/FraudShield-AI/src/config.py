"""Central configuration: paths, column names and training defaults."""
from __future__ import annotations

from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]

DATA_DIR = PROJECT_ROOT / "data"
MODELS_DIR = PROJECT_ROOT / "models"
RUNS_DIR = MODELS_DIR / "runs"
REPORTS_DIR = PROJECT_ROOT / "reports"  # legacy/root placeholder; active reports live inside each run
FIGURES_DIR = REPORTS_DIR / "figures"

DATASET_PATH = DATA_DIR / "creditcard.csv"
DATASET_URL = "https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud"
KAGGLE_SLUG = "mlg-ulb/creditcardfraud"

# Raw columns in the Kaggle file
TARGET = "Class"
PCA_FEATURES = [f"V{i}" for i in range(1, 29)]
RAW_FEATURES = ["Time", *PCA_FEATURES, "Amount"]
REQUIRED_COLUMNS = [*RAW_FEATURES, TARGET]

# Model input features after preprocessing (see src/preprocessing.py).
# Time is an elapsed-seconds field, not a wall-clock timestamp. Its daily phase is
# represented continuously by a sine/cosine pair to avoid a midnight discontinuity.
MODEL_FEATURES = [*PCA_FEATURES, "Amount", "TimeSin", "TimeCos"]

# Active-run pointer. A complete run is written into models/runs/<run_id>/ and this
# file is atomically replaced only after every artifact is ready.
METADATA_PATH = MODELS_DIR / "metadata.json"

# Legacy root paths retained for migration/backwards compatibility.
PREPROCESSOR_PATH = MODELS_DIR / "preprocessor.joblib"
SHAP_BACKGROUND_PATH = MODELS_DIR / "shap_background.joblib"
METRICS_PATH = REPORTS_DIR / "metrics.json"
COMPARISON_PATH = REPORTS_DIR / "model_comparison.csv"
CURVES_PATH = REPORTS_DIR / "curves.json"
TEST_PREDICTIONS_PATH = REPORTS_DIR / "test_predictions.csv"
EDA_SUMMARY_PATH = REPORTS_DIR / "eda_summary.json"
SHAP_IMPORTANCE_PATH = REPORTS_DIR / "shap_importance.csv"

MODEL_NAMES = {
    "logistic_regression": "Logistic Regression",
    "random_forest": "Random Forest",
    "xgboost": "XGBoost",
    "isolation_forest": "Isolation Forest",
}

RANDOM_STATE = 42
TEST_SIZE = 0.20         # latest 20% for chronological evaluation by default
VAL_SIZE = 0.20          # fraction of the remaining data used for validation
SMOTE_RATIO = 0.10       # minority resampled to 10% of majority (training folds only)
SHAP_BACKGROUND_SIZE = 200


def model_path(key: str, run_dir: Path | None = None) -> Path:
    """Return the model path for a specific run (or the legacy root layout)."""
    return (run_dir or MODELS_DIR) / f"{key}.joblib"


def run_dir_from_metadata(metadata: dict) -> Path:
    """Resolve an artifact directory recorded in metadata, with legacy fallback."""
    relative = metadata.get("artifact_dir")
    if relative:
        root = (MODELS_DIR / relative).resolve()
        # Prevent a malformed metadata file from resolving outside the models directory.
        if MODELS_DIR.resolve() not in root.parents:
            raise ValueError("Invalid artifact_dir in models/metadata.json")
        return root
    return MODELS_DIR


def run_artifact_path(metadata: dict, relative_path: str) -> Path:
    return run_dir_from_metadata(metadata) / relative_path


def ensure_dirs() -> None:
    for d in (DATA_DIR, MODELS_DIR, RUNS_DIR, REPORTS_DIR, FIGURES_DIR):
        d.mkdir(parents=True, exist_ok=True)
