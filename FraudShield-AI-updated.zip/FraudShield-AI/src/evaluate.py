"""Evaluation utilities. Every number is computed from held-out predictions."""
from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import (
    average_precision_score, confusion_matrix, f1_score, precision_recall_curve,
    precision_score, recall_score, roc_auc_score, roc_curve,
)

from .eda import BLUE, RED, TEXT, set_style


def best_f1_threshold(y_true, scores) -> float:
    """Decision threshold maximizing F1 on validation data (kept as a baseline)."""
    precision, recall, thresholds = precision_recall_curve(y_true, scores)
    f1 = 2 * precision * recall / np.clip(precision + recall, 1e-12, None)
    idx = int(np.nanargmax(f1[:-1])) if len(thresholds) else 0
    return float(thresholds[idx]) if len(thresholds) else 0.5


def cost_sensitive_threshold(y_true, scores, false_negative_cost: float = 10.0,
                             false_positive_cost: float = 1.0) -> float:
    """Choose a validation threshold minimizing relative weighted FP/FN cost.

    Costs are configurable relative weights, not calibrated currency amounts. The
    selected threshold should be revisited with real operational loss data.
    """
    if false_negative_cost <= 0 or false_positive_cost <= 0:
        raise ValueError("False-negative and false-positive costs must both be positive.")
    y = np.asarray(y_true, dtype=int)
    s = np.asarray(scores, dtype=float)
    if y.ndim != 1 or s.ndim != 1 or len(y) != len(s) or not len(y):
        raise ValueError("y_true and scores must be non-empty one-dimensional arrays of equal length.")
    if not np.isfinite(s).all():
        raise ValueError("Scores contain non-finite values.")
    if len(np.unique(y)) < 2:
        raise ValueError("Threshold selection requires both classes in validation data.")

    precision, recall, thresholds = precision_recall_curve(y, s)
    if not len(thresholds):
        return 0.5
    positives = float(y.sum())
    tp = recall[:-1] * positives
    fn = positives - tp
    fp = np.divide(tp * (1.0 - precision[:-1]), precision[:-1],
                   out=np.zeros_like(tp), where=precision[:-1] > 0)
    total_cost = false_negative_cost * fn + false_positive_cost * fp
    # Include a threshold just above the maximum score so an all-negative operating
    # point is available when false positives are more expensive than missed fraud.
    no_flag_threshold = float(np.nextafter(np.max(s), np.inf))
    no_flag_cost = false_negative_cost * positives
    candidates = np.append(total_cost, no_flag_cost)
    best = np.flatnonzero(np.isclose(candidates, np.nanmin(candidates), rtol=1e-12, atol=1e-12))
    # On ties, prefer the higher threshold (fewer reviews / false positives).
    idx = int(best[-1])
    return no_flag_threshold if idx == len(thresholds) else float(thresholds[idx])


def compute_metrics(y_true, scores, threshold: float, false_negative_cost: float = 10.0,
                    false_positive_cost: float = 1.0) -> dict:
    y_true = np.asarray(y_true, dtype=int)
    scores = np.asarray(scores, dtype=float)
    y_pred = (scores >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    weighted_cost = float(false_negative_cost * fn + false_positive_cost * fp)
    n = max(len(y_true), 1)
    return {
        "threshold": float(threshold),
        "precision": float(precision_score(y_true, y_pred, zero_division=0)),
        "recall": float(recall_score(y_true, y_pred, zero_division=0)),
        "f1": float(f1_score(y_true, y_pred, zero_division=0)),
        "roc_auc": float(roc_auc_score(y_true, scores)),
        "pr_auc": float(average_precision_score(y_true, scores)),
        "accuracy": float((tp + tn) / n),
        "confusion_matrix": {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)},
        "n_samples": int(len(y_true)),
        "n_fraud": int(y_true.sum()),
        "weighted_error_cost": weighted_cost,
        "weighted_cost_per_1000": float(1000.0 * weighted_cost / n),
        "false_negative_cost_weight": float(false_negative_cost),
        "false_positive_cost_weight": float(false_positive_cost),
    }


def curve_points(y_true, scores, max_points: int = 300) -> dict:
    """Down-sampled ROC & PR curve points for the dashboard."""
    fpr, tpr, _ = roc_curve(y_true, scores)
    prec, rec, _ = precision_recall_curve(y_true, scores)

    def thin(*arrs):
        n = len(arrs[0])
        idx = np.unique(np.linspace(0, n - 1, min(n, max_points)).astype(int))
        return [np.round(a[idx], 5).tolist() for a in arrs]

    fpr, tpr = thin(fpr, tpr)
    rec, prec = thin(rec, prec)
    return {"roc": {"fpr": fpr, "tpr": tpr}, "pr": {"recall": rec, "precision": prec}}


def plot_curves(results: dict, y_true, out_dir: Path) -> None:
    """ROC + PR curves for all models on the test set. results[name] = scores."""
    set_style()
    colors = [BLUE, RED, "#22C55E", "#F59E0B", "#A78BFA"]
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(12, 5))
    for (name, scores), c in zip(results.items(), colors):
        fpr, tpr, _ = roc_curve(y_true, scores)
        prec, rec, _ = precision_recall_curve(y_true, scores)
        a1.plot(fpr, tpr, color=c, lw=2, label=f"{name} (AUC={roc_auc_score(y_true, scores):.3f})")
        a2.plot(rec, prec, color=c, lw=2, label=f"{name} (AP={average_precision_score(y_true, scores):.3f})")
    a1.plot([0, 1], [0, 1], "--", color="#475569")
    a1.set(title="ROC curve (test set)", xlabel="False positive rate", ylabel="True positive rate")
    base = float(np.mean(y_true))
    a2.axhline(base, ls="--", color="#475569", label=f"Baseline ({base:.4f})")
    a2.set(title="Precision-Recall curve (test set)", xlabel="Recall", ylabel="Precision")
    a1.legend(loc="lower right", fontsize=8)
    a2.legend(loc="lower left", fontsize=8)
    fig.tight_layout()
    out_dir.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_dir / "07_roc_pr_curves.png", dpi=130)
    plt.close(fig)


def plot_confusion_matrices(metrics: dict, out_dir: Path) -> None:
    set_style()
    n = len(metrics)
    fig, axes = plt.subplots(1, n, figsize=(4.2 * n, 4))
    axes = np.atleast_1d(axes)
    for ax, (name, m) in zip(axes, metrics.items()):
        cm = m["confusion_matrix"]
        mat = np.array([[cm["tn"], cm["fp"]], [cm["fn"], cm["tp"]]])
        shade = np.log1p(mat)
        ax.imshow(shade, cmap="Blues", vmin=0, vmax=max(float(shade.max()), 1e-9))
        for (i, j), v in np.ndenumerate(mat):
            dark_cell = shade[i, j] > 0.55 * max(float(shade.max()), 1e-9)
            color = "white" if dark_cell else ("#B91C1C" if i != j else "#0B1220")
            ax.text(j, i, f"{v:,}", ha="center", va="center", color=color, fontsize=12, fontweight="bold")
        ax.set_xticks([0, 1], ["Legit", "Fraud"])
        ax.set_yticks([0, 1], ["Legit", "Fraud"])
        ax.set_xlabel("Predicted")
        ax.set_ylabel("Actual")
        ax.set_title(f"{name}\nthreshold={m['threshold']:.3f}", fontsize=10)
        ax.grid(False)
    fig.tight_layout()
    out_dir.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_dir / "08_confusion_matrices.png", dpi=130)
    plt.close(fig)
