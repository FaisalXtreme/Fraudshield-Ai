"""Model definitions, fold-local preprocessing and imbalance handling."""
from __future__ import annotations

import numpy as np
from scipy.stats import loguniform
from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.ensemble import IsolationForest, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline as SklearnPipeline

from . import config
from .preprocessing import FraudPreprocessor
from .utils import get_logger, is_available

log = get_logger()
HAS_XGB = is_available("xgboost")
HAS_IMBLEARN = is_available("imblearn")


class IsolationForestDetector(ClassifierMixin, BaseEstimator):
    """Expose a normalized 0..1 anomaly risk score from Isolation Forest.

    This is deliberately called a score, never a probability. Its 0..1 scale is a
    training-range normalization for display/ranking, not statistical calibration.
    """

    def __init__(self, n_estimators: int = 200, max_samples="auto", contamination="auto",
                 random_state: int = config.RANDOM_STATE):
        self.n_estimators = n_estimators
        self.max_samples = max_samples
        self.contamination = contamination
        self.random_state = random_state
        self.model = IsolationForest(n_estimators=n_estimators, max_samples=max_samples,
                                     contamination=contamination, random_state=random_state, n_jobs=-1)
        self.lo_: float | None = None
        self.hi_: float | None = None

    def fit(self, X, y=None):
        self.model.fit(X)
        self.classes_ = np.array([0, 1], dtype=int)
        scores = -self.model.score_samples(X)
        self.lo_ = float(np.percentile(scores, 0.5))
        self.hi_ = float(np.percentile(scores, 99.9))
        if not np.isfinite(self.lo_) or not np.isfinite(self.hi_) or self.hi_ <= self.lo_:
            self.lo_, self.hi_ = float(np.min(scores)), float(np.max(scores) + 1e-12)
        return self

    def anomaly_score(self, X) -> np.ndarray:
        if self.lo_ is None or self.hi_ is None:
            raise RuntimeError("IsolationForestDetector must be fitted before scoring.")
        scores = -self.model.score_samples(X)
        return np.clip((scores - self.lo_) / max(self.hi_ - self.lo_, 1e-12), 0.0, 1.0)

    def predict_proba(self, X) -> np.ndarray:
        score = self.anomaly_score(X)
        return np.column_stack([1.0 - score, score])


# Base estimators retained for direct unit testing and backward familiarity.
def build_model(key: str, scale_pos_weight: float = 1.0):
    if key == "logistic_regression":
        return LogisticRegression(class_weight="balanced", C=0.1, max_iter=2500, solver="lbfgs")

    if key == "random_forest":
        rf = RandomForestClassifier(n_estimators=250, max_depth=12, min_samples_leaf=2,
                                    max_features="sqrt", n_jobs=-1, random_state=config.RANDOM_STATE,
                                    class_weight=None if HAS_IMBLEARN else "balanced_subsample")
        if HAS_IMBLEARN:
            from imblearn.over_sampling import SMOTE
            from imblearn.pipeline import Pipeline as ImblearnPipeline
            return ImblearnPipeline([
                ("smote", SMOTE(sampling_strategy=config.SMOTE_RATIO, random_state=config.RANDOM_STATE,
                                 k_neighbors=3)),
                ("clf", rf),
            ])
        log.warning("imbalanced-learn not installed -> Random Forest uses class_weight instead of SMOTE")
        return rf

    if key == "xgboost":
        if not HAS_XGB:
            raise ImportError("xgboost is not installed. Run: pip install xgboost")
        from xgboost import XGBClassifier
        return XGBClassifier(
            n_estimators=450, max_depth=4, learning_rate=0.05, subsample=0.85, colsample_bytree=0.8,
            min_child_weight=2, gamma=0.0, reg_lambda=2.0, scale_pos_weight=scale_pos_weight,
            eval_metric="aucpr", tree_method="hist", n_jobs=-1, random_state=config.RANDOM_STATE,
        )

    if key == "isolation_forest":
        return IsolationForestDetector()

    raise ValueError(f"Unknown model key: {key}")


def build_training_pipeline(key: str, scale_pos_weight: float = 1.0,
                            isolation_params: dict | None = None):
    """Build a full raw-data pipeline. Preprocessing is fitted within each CV fold."""
    if key == "isolation_forest":
        params = isolation_params or {}
        return SklearnPipeline([
            ("preprocessor", FraudPreprocessor()),
            ("detector", IsolationForestDetector(**params)),
        ])

    base = build_model(key, scale_pos_weight=scale_pos_weight)
    steps = [("preprocessor", FraudPreprocessor())]
    if hasattr(base, "steps"):
        steps.extend(base.steps)
        # The imblearn Pipeline handles SMOTE during fit and bypasses it at prediction.
        from imblearn.pipeline import Pipeline as ImblearnPipeline
        return ImblearnPipeline(steps)
    steps.append(("clf", base))
    return SklearnPipeline(steps)


def param_space(key: str, model=None) -> dict:
    """Randomized-search distributions using pipeline parameter names."""
    if key == "logistic_regression":
        return {"clf__C": loguniform(1e-3, 10)}
    if key == "random_forest":
        return {
            "clf__n_estimators": [150, 250, 350],
            "clf__max_depth": [8, 12, 16, None],
            "clf__min_samples_leaf": [1, 2, 4],
            "clf__max_features": ["sqrt", 0.3],
        }
    if key == "xgboost":
        return {
            "clf__n_estimators": [250, 450, 650],
            "clf__max_depth": [3, 4, 5, 6],
            "clf__learning_rate": [0.03, 0.05, 0.1],
            "clf__subsample": [0.7, 0.85, 1.0],
            "clf__colsample_bytree": [0.6, 0.8, 1.0],
            "clf__min_child_weight": [1, 3, 5],
            "clf__reg_lambda": [1.0, 2.0, 5.0],
        }
    return {}


ISOLATION_FOREST_GRID = [
    {"n_estimators": 200, "max_samples": "auto"},
    {"n_estimators": 300, "max_samples": 512},
    {"n_estimators": 300, "max_samples": 2048},
]


def final_estimator(model):
    """Return the final fitted estimator (keeps the IF wrapper for score explanations)."""
    if hasattr(model, "named_steps"):
        if "detector" in model.named_steps:
            return model.named_steps["detector"]
        if "clf" in model.named_steps:
            return model.named_steps["clf"]
        return list(model.named_steps.values())[-1]
    if isinstance(model, IsolationForestDetector):
        return model
    if hasattr(model, "named_steps") and "clf" in model.named_steps:
        return model.named_steps["clf"]
    return model


def available_models() -> list[str]:
    keys = ["logistic_regression", "random_forest"]
    if HAS_XGB:
        keys.append("xgboost")
    else:
        log.warning("xgboost not installed -> XGBoost will be skipped. Run: pip install xgboost")
    keys.append("isolation_forest")
    return keys
