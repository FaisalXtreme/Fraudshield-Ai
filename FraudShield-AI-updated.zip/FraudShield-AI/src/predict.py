"""Inference: load a versioned training run and score new transactions."""
from __future__ import annotations

import joblib
import numpy as np
import pandas as pd

from . import config
from .utils import load_json


class ArtifactsNotFoundError(FileNotFoundError):
    pass


def risk_level(risk_score: float, threshold: float) -> str:
    """High = at/above threshold; Medium = at least half the threshold."""
    if risk_score >= threshold:
        return "High"
    if risk_score >= threshold / 2:
        return "Medium"
    return "Low"


class FraudPredictor:
    def __init__(self, model_key: str | None = None, run_id: str | None = None):
        if not config.METADATA_PATH.exists():
            raise ArtifactsNotFoundError("No trained models found. Run:  python train.py")
        self.metadata = load_json(config.METADATA_PATH)
        if self.metadata.get("schema_version", 1) < 2:
            raise ArtifactsNotFoundError("Trained artifacts use an older feature schema. Re-train with this version: python train.py")
        self.run_id = str(self.metadata.get("run_id") or config.METADATA_PATH.stat().st_mtime_ns)
        if run_id and self.run_id != run_id:
            raise ArtifactsNotFoundError("The active training run changed. Refresh the dashboard and retry.")
        self.model_key = model_key or self.metadata["best_model"]
        if self.model_key not in self.metadata["models"]:
            raise ValueError(f"Model '{self.model_key}' was not trained. "
                             f"Available: {list(self.metadata['models'])}")
        self.run_dir = config.run_dir_from_metadata(self.metadata)
        path = config.model_path(self.model_key, self.run_dir)
        pre_path = self.run_dir / "preprocessor.joblib"
        if not path.exists() or not pre_path.exists():
            raise ArtifactsNotFoundError(f"Missing trained artifacts for run {self.run_id}. Re-run: python train.py")
        self.model = joblib.load(path)
        self.preprocessor = joblib.load(pre_path)
        self.threshold = float(self.metadata["models"][self.model_key]["threshold"])
        self.label = config.MODEL_NAMES[self.model_key]

    def transform(self, raw: pd.DataFrame) -> pd.DataFrame:
        return self.preprocessor.transform(raw)

    def score(self, raw: pd.DataFrame) -> np.ndarray:
        """Return model risk scores in [0, 1]; they are not calibrated probabilities."""
        if not isinstance(raw, pd.DataFrame):
            raw = pd.DataFrame(raw, columns=config.RAW_FEATURES)
        missing = [c for c in config.RAW_FEATURES if c not in raw.columns]
        if missing:
            raise ValueError(f"Input is missing required columns: {missing}")
        score = np.asarray(self.model.predict_proba(raw[config.RAW_FEATURES])[:, 1], dtype=float)
        if not np.isfinite(score).all():
            raise ValueError("Model produced a non-finite risk score.")
        return np.clip(score, 0.0, 1.0)

    def predict(self, raw: pd.DataFrame) -> pd.DataFrame:
        score = self.score(raw)
        return pd.DataFrame({
            "risk_score": score,
            "prediction": np.where(score >= self.threshold, "Suspicious", "Not flagged"),
            "risk_level": [risk_level(x, self.threshold) for x in score],
        })
