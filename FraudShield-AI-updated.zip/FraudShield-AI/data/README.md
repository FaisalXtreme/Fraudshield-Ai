# data/

Place the Kaggle file here as **`data/creditcard.csv`** (about 144 MB, 284,807 rows, 31 columns).

Download: https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud

**Browser:** sign in to Kaggle, click *Download*, unzip, move `creditcard.csv` into this folder.

**Kaggle CLI:**
```bash
pip install kaggle
# save your API token (Kaggle > Settings > API > Create New Token) as ~/.kaggle/kaggle.json
kaggle datasets download -d mlg-ulb/creditcardfraud -p data --unzip
```

The file is git-ignored because of its size and licence (ODbL). Do not commit it.
