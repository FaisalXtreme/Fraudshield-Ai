"""Visual theme: colours, global CSS, Plotly styling and small HTML components."""
from __future__ import annotations

import html

import plotly.graph_objects as go
import streamlit as st

NAVY = "#0A1628"
PANEL = "#111D35"
BORDER = "#1E2D4A"
BLUE = "#3B82F6"
SKY = "#60A5FA"
TEXT = "#E2E8F0"
MUTED = "#94A3B8"
RED = "#F43F5E"
AMBER = "#F59E0B"
GREEN = "#10B981"
RISK_COLORS = {"Low": GREEN, "Medium": AMBER, "High": RED}
MODEL_COLORS = [BLUE, RED, GREEN, AMBER]

CSS = f"""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
html, body, [class*="css"], .stMarkdown, .stText {{ font-family: 'Inter', sans-serif; }}
.block-container {{ padding-top: 2rem; padding-bottom: 3rem; max-width: 1400px; }}
section[data-testid="stSidebar"] {{ background: #0D1B33; border-right: 1px solid {BORDER}; }}
h1, h2, h3 {{ color: {TEXT}; letter-spacing: -0.01em; }}
.fs-header h1 {{ font-size: 1.75rem; font-weight: 700; margin: 0; }}
.fs-header p {{ color: {MUTED}; margin: .25rem 0 1.25rem 0; }}
.kpi {{ background: {PANEL}; border: 1px solid {BORDER}; border-radius: 12px; padding: 18px 20px;
        border-top: 3px solid var(--accent); height: 100%; }}
.kpi .label {{ color: {MUTED}; font-size: .78rem; text-transform: uppercase; letter-spacing: .06em; font-weight: 600; }}
.kpi .value {{ color: {TEXT}; font-size: 1.85rem; font-weight: 700; margin-top: 6px; line-height: 1.1; }}
.kpi .sub {{ color: {MUTED}; font-size: .8rem; margin-top: 6px; }}
.card {{ background: {PANEL}; border: 1px solid {BORDER}; border-radius: 12px; padding: 18px 20px; }}
.badge {{ display: inline-block; padding: 4px 12px; border-radius: 999px; font-weight: 600; font-size: .85rem; }}
.note {{ background: rgba(59,130,246,.08); border: 1px solid rgba(59,130,246,.35); border-radius: 10px;
         padding: 12px 16px; color: {TEXT}; font-size: .88rem; }}
.reason {{ padding: 8px 0; border-bottom: 1px solid {BORDER}; font-size: .92rem; }}
.reason:last-child {{ border-bottom: none; }}
div[data-testid="stMetric"] {{ background: {PANEL}; border: 1px solid {BORDER}; border-radius: 12px; padding: 12px 16px; }}
</style>
"""


def apply_css() -> None:
    st.markdown(CSS, unsafe_allow_html=True)


def header(title: str, subtitle: str) -> None:
    st.markdown(f'<div class="fs-header"><h1>{html.escape(title)}</h1><p>{html.escape(subtitle)}</p></div>',
                unsafe_allow_html=True)


def kpi(label: str, value: str, sub: str = "", accent: str = BLUE) -> None:
    st.markdown(
        f'<div class="kpi" style="--accent:{accent}"><div class="label">{html.escape(label)}</div>'
        f'<div class="value">{html.escape(value)}</div><div class="sub">{html.escape(sub)}</div></div>',
        unsafe_allow_html=True,
    )


def badge(text: str, color: str) -> str:
    return (f'<span class="badge" style="background:{color}22;color:{color};border:1px solid {color}66">'
            f'{html.escape(text)}</span>')


def note(text_html: str) -> None:
    st.markdown(f'<div class="note">{text_html}</div>', unsafe_allow_html=True)


def style_fig(fig: go.Figure, height: int = 360, title: str | None = None) -> go.Figure:
    fig.update_layout(
        height=height, title=dict(text=title, font=dict(size=15, color=TEXT)) if title else None,
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor=PANEL, font=dict(family="Inter, sans-serif", color=TEXT),
        margin=dict(l=10, r=10, t=50 if title else 20, b=10),
        legend=dict(bgcolor="rgba(0,0,0,0)", font=dict(color=MUTED)),
        hoverlabel=dict(bgcolor=NAVY, font_color=TEXT),
    )
    fig.update_xaxes(gridcolor=BORDER, zerolinecolor=BORDER, color=MUTED)
    fig.update_yaxes(gridcolor=BORDER, zerolinecolor=BORDER, color=MUTED)
    return fig
