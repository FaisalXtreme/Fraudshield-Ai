"""Cached access to one immutable, versioned training run."""
from __future__ import annotations

import joblib
import pandas as pd
import streamlit as st

from src import config
from src.explain import FraudExplainer
from src.predict import FraudPredictor
from src.utils import load_json


def _active_metadata() -> dict | None:
    if not config.METADATA_PATH.exists():
        return None
    try:
        return load_json(config.METADATA_PATH)
    except Exception:
        return None


def version() -> str:
    """Unique cache key: each successful train commits a new immutable run ID."""
    metadata = _active_metadata()
    if metadata is None:
        return "no-active-run"
    return str(metadata.get("run_id") or config.METADATA_PATH.stat().st_mtime_ns)


def artifacts_ready() -> bool:
    metadata = _active_metadata()
    if not metadata or metadata.get("schema_version", 1) < 2:
        return False
    run_dir = config.run_dir_from_metadata(metadata)
    needed = [run_dir / "preprocessor.joblib", run_dir / "reports" / "model_comparison.csv",
              run_dir / "reports" / "test_predictions.csv", run_dir / "reports" / "metrics.json"]
    return all(path.exists() for path in needed) and all(
        config.model_path(key, run_dir).exists() for key in metadata.get("models", {})
    )


@st.cache_data(show_spinner=False)
def metadata(run_id: str) -> dict:
    current = load_json(config.METADATA_PATH)
    identity = str(current.get("run_id") or config.METADATA_PATH.stat().st_mtime_ns)
    if identity != run_id:
        raise RuntimeError("The active training run changed. Refresh the dashboard.")
    return current


def artifact_path(run_id: str, relative_path: str):
    current = load_json(config.METADATA_PATH)
    identity = str(current.get("run_id") or config.METADATA_PATH.stat().st_mtime_ns)
    if identity != run_id:
        raise RuntimeError("The active training run changed. Refresh the dashboard.")
    return config.run_artifact_path(current, relative_path)


@st.cache_data(show_spinner=False)
def comparison(run_id: str) -> pd.DataFrame:
    return pd.read_csv(artifact_path(run_id, "reports/model_comparison.csv"))


@st.cache_data(show_spinner=False)
def metrics(run_id: str) -> dict:
    return load_json(artifact_path(run_id, "reports/metrics.json"))


@st.cache_data(show_spinner=False)
def curves(run_id: str) -> dict:
    path = artifact_path(run_id, "reports/curves.json")
    return load_json(path) if path.exists() else {}


@st.cache_data(show_spinner="Loading transaction history...")
def history(run_id: str) -> pd.DataFrame:
    return pd.read_csv(artifact_path(run_id, "reports/test_predictions.csv"))


@st.cache_data(show_spinner=False)
def shap_importance(run_id: str) -> pd.DataFrame | None:
    path = artifact_path(run_id, "reports/shap_importance.csv")
    return pd.read_csv(path) if path.exists() else None


@st.cache_resource(show_spinner="Loading model...")
def predictor(model_key: str, run_id: str) -> FraudPredictor:
    return FraudPredictor(model_key, run_id=run_id)


@st.cache_resource(show_spinner="Preparing SHAP explainer...")
def explainer(model_key: str, run_id: str) -> FraudExplainer | None:
    background_path = artifact_path(run_id, "shap_background.joblib")
    if not background_path.exists():
        return None
    background = joblib.load(background_path)
    return FraudExplainer(predictor(model_key, run_id).model, model_key, background)
