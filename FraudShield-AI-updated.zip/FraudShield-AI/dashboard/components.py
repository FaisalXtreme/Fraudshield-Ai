"""Reusable dashboard widgets: risk gauge, prediction card and SHAP explanation."""
from __future__ import annotations

import html

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from src.explain import top_factors

from . import data
from .theme import AMBER, BLUE, BORDER, GREEN, MUTED, RED, RISK_COLORS, TEXT, badge, note, style_fig

DISCLAIMER = (
    "<b>Risk estimate, not a verdict.</b> The score is a model-based estimate of how closely this "
    "transaction is associated with patterns the model learned from the training data. It is not a definitive fraud determination "
    "and should trigger review, not automatic action."
)


def gauge(score: float, threshold: float, title: str = "Model risk score (0-1)") -> go.Figure:
    visual_threshold = float(np.clip(threshold, 0.0, 1.0))
    color = RED if score >= threshold else (AMBER if score >= threshold / 2 else GREEN)
    fig = go.Figure(go.Indicator(
        mode="gauge+number", value=score, number={"valueformat": ".3f",
                                                       "font": {"size": 40, "color": TEXT}},
        title={"text": title, "font": {"size": 14, "color": MUTED}},
        gauge={
            "axis": {"range": [0, 1], "tickcolor": MUTED, "tickfont": {"color": MUTED}},
            "bar": {"color": color, "thickness": 0.3},
            "bgcolor": "#0D1B33", "borderwidth": 1, "bordercolor": BORDER,
            "steps": [{"range": [0, visual_threshold / 2], "color": "rgba(16,185,129,.12)"},
                      {"range": [visual_threshold / 2, visual_threshold], "color": "rgba(245,158,11,.12)"},
                      {"range": [visual_threshold, 1], "color": "rgba(244,63,94,.12)"}],
            "threshold": {"line": {"color": TEXT, "width": 3}, "thickness": 0.85,
                          "value": visual_threshold},
        },
    ))
    return style_fig(fig, height=260)


def result_card(score: float, threshold: float, risk: str, model_label: str, threshold_note: str = "weighted validation error cost") -> None:
    decision = "Suspicious - review recommended" if score >= threshold else "Not flagged by this model"
    st.markdown(
        f'<div class="card"><div style="color:{MUTED};font-size:.8rem;text-transform:uppercase;'
        f'letter-spacing:.06em;font-weight:600">Assessment</div>'
        f'<div style="font-size:1.35rem;font-weight:700;margin:8px 0">{html.escape(decision)}</div>'
        f'{badge(f"{risk} risk", RISK_COLORS[risk])}'
        f'<div style="color:{MUTED};font-size:.85rem;margin-top:14px">'
        f'Model: <b style="color:{TEXT}">{html.escape(model_label)}</b><br>'
        f'Decision threshold: <b style="color:{TEXT}">{threshold:.3f}</b> '
        f'(selected by {html.escape(threshold_note)})</div></div>',
        unsafe_allow_html=True,
    )


def shap_bar(shap_row: np.ndarray, feature_names: list[str], units: str, k: int = 12) -> go.Figure:
    order = np.argsort(np.abs(shap_row))[-k:]
    vals = shap_row[order]
    names = [feature_names[i] for i in order]
    fig = go.Figure(go.Bar(
        x=vals, y=names, orientation="h", marker_color=[RED if v > 0 else BLUE for v in vals],
        hovertemplate="%{y}: %{x:+.4f}<extra></extra>",
    ))
    fig.add_vline(x=0, line_color=MUTED, line_width=1)
    fig.update_xaxes(title=f"SHAP value ({units})  -  red raises risk, blue lowers it")
    return style_fig(fig, height=max(300, 30 * len(names) + 80), title="Why this score? Feature contributions")


def _describe(f: dict) -> str:
    name = f.get("display_name", f["feature"])
    if f["feature"] == "Amount" and f["value"] is not None:
        what = f"Transaction amount ({f['value']:,.2f})"
    elif f["feature"] in {"TimeSin", "TimeCos"}:
        what = f["display_name"]
    elif f["value"] is not None:
        what = f"{name} = {f['value']:.3f}"
    else:
        what = name
    color = RED if f["direction"] == "increases" else GREEN
    arrow = "&#9650;" if f["direction"] == "increases" else "&#9660;"
    return (f'<div class="reason"><span style="color:{color};font-weight:700">{arrow} '
            f'{f["direction"]} risk</span> &nbsp; {html.escape(what)} '
            f'<span style="color:{MUTED}">({f["shap_value"]:+.4f})</span></div>')


def explain_transaction(raw_row: pd.DataFrame, model_key: str) -> None:
    """Render local SHAP explanation for a single raw transaction."""
    run_id = data.version()
    exp = data.explainer(model_key, run_id)
    if exp is None or not exp.available:
        st.info("SHAP explanations are unavailable for this model. Install SHAP with `pip install shap`, "
                "then restart the dashboard.")
        return
    try:
        X = data.predictor(model_key, run_id).transform(raw_row)
        vals, base = exp.explain(X)
    except Exception as exc:
        st.warning(f"Could not compute explanation: {exc}")
        return
    row = vals[0]
    c1, c2 = st.columns([3, 2])
    with c1:
        st.plotly_chart(shap_bar(row, exp.feature_names, exp.units), width="stretch")
    with c2:
        st.markdown("##### Top factors")
        factors = top_factors(row, exp.feature_names, raw_row.iloc[0], k=6)
        st.markdown('<div class="card">' + "".join(_describe(f) for f in factors) + "</div>",
                    unsafe_allow_html=True)
        up = row[row > 0].sum()
        down = row[row < 0].sum()
        st.caption(f"Baseline output {base:+.3f} {exp.units}; features raising risk add {up:+.3f}, "
                   f"features lowering risk add {down:+.3f}. V1-V28 are anonymised PCA components "
                   f"released by the dataset authors, so their business meaning is not public.")


def disclaimer() -> None:
    note(DISCLAIMER)
