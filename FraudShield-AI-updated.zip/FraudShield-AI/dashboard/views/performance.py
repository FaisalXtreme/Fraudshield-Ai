"""Model performance comparison - all values read from reports written by train.py."""
from __future__ import annotations

import numpy as np
import plotly.graph_objects as go
import streamlit as st

from .. import data
from ..theme import MODEL_COLORS, MUTED, header, note, style_fig


def render() -> None:
    run_id = data.version()
    meta, comp, curves = data.metadata(run_id), data.comparison(run_id), data.curves(run_id)
    header("Model Performance", "Test-set metrics computed from actual predictions on held-out data")

    best = comp[comp.is_best].iloc[0] if comp.is_best.any() else comp.iloc[0]
    c = st.columns(5)
    for col, (label, key) in zip(c, [("Precision", "precision"), ("Recall", "recall"), ("F1-score", "f1"),
                                     ("ROC-AUC", "roc_auc"), ("PR-AUC", "pr_auc")]):
        col.metric(f"{label} - {best.model}", f"{best[key]:.4f}")

    st.write("")
    table = comp[["model", "precision", "recall", "f1", "roc_auc", "pr_auc", "accuracy", "threshold",
                  "tp", "fp", "fn", "tn", "weighted_cost_per_1000", "train_seconds", "is_best"]]
    fmt = {k: st.column_config.NumberColumn(format="%.4f") for k in
           ["precision", "recall", "f1", "roc_auc", "pr_auc", "accuracy", "threshold"]}
    st.dataframe(table, hide_index=True, width="stretch", column_config={
        **fmt, "model": "Model", "is_best": st.column_config.CheckboxColumn("Selected"),
        "train_seconds": st.column_config.NumberColumn("Train time (s)", format="%.1f"),
        "weighted_cost_per_1000": st.column_config.NumberColumn("Weighted error cost / 1k", format="%.1f"),
        "tp": "TP", "fp": "FP", "fn": "FN", "tn": "TN",
    })
    rate = 100 * meta["dataset"]["fraud_rate"]
    note(f"<b>Why not accuracy?</b> Fraud is {rate:.3f}% of transactions in this dataset, so a model that "
         f"predicts 'legitimate' for everything scores {100 - rate:.2f}% accuracy while catching zero fraud. "
         "PR-AUC (average precision) is the primary metric; the best model was chosen on "
         "<i>validation</i> PR-AUC so the test set stays an unbiased estimate. Thresholds use "
         f"relative error weights FN={meta['threshold_selection']['false_negative_cost_weight']:g}, "
         f"FP={meta['threshold_selection']['false_positive_cost_weight']:g}; these are not currency amounts.")
    st.write("")

    metrics = ["precision", "recall", "f1", "roc_auc", "pr_auc"]
    fig = go.Figure()
    for (_, r), color in zip(comp.iterrows(), MODEL_COLORS):
        fig.add_bar(name=r.model, x=["Precision", "Recall", "F1", "ROC-AUC", "PR-AUC"],
                    y=[r[m] for m in metrics], marker_color=color, text=[f"{r[m]:.3f}" for m in metrics],
                    textposition="outside")
    fig.update_layout(barmode="group")
    fig.update_yaxes(range=[0, 1.1])
    st.plotly_chart(style_fig(fig, 400, "Metric comparison (test set)"), width="stretch")

    if curves:
        c1, c2 = st.columns(2)
        roc, pr = go.Figure(), go.Figure()
        for (name, cv), color in zip(curves.items(), MODEL_COLORS):
            roc.add_scatter(x=cv["roc"]["fpr"], y=cv["roc"]["tpr"], name=name, line=dict(color=color, width=2))
            pr.add_scatter(x=cv["pr"]["recall"], y=cv["pr"]["precision"], name=name,
                           line=dict(color=color, width=2))
        roc.add_scatter(x=[0, 1], y=[0, 1], name="Random", line=dict(color=MUTED, dash="dash"))
        roc.update_xaxes(title="False positive rate")
        roc.update_yaxes(title="True positive rate")
        pr.update_xaxes(title="Recall")
        pr.update_yaxes(title="Precision")
        c1.plotly_chart(style_fig(roc, 380, "ROC curve"), width="stretch")
        c2.plotly_chart(style_fig(pr, 380, "Precision-Recall curve"), width="stretch")

    st.subheader("Confusion matrix")
    name = st.selectbox("Model", comp.model.tolist(), index=int(np.argmax(comp.is_best.values)))
    r = comp[comp.model == name].iloc[0]
    mat = np.array([[r.tn, r.fp], [r.fn, r.tp]])
    fig = go.Figure(go.Heatmap(
        z=np.log1p(mat), x=["Predicted legit", "Predicted fraud"], y=["Actual legit", "Actual fraud"],
        text=[[f"{x:,}" for x in row] for row in mat], texttemplate="%{text}",
        textfont=dict(size=20), colorscale="Blues", showscale=False, hoverinfo="skip",
    ))
    fig.update_yaxes(autorange="reversed")
    c1, c2 = st.columns([2, 3])
    c1.plotly_chart(style_fig(fig, 320), width="stretch")
    with c2:
        st.markdown(f"""
- **True positives {r.tp:,}** - frauds correctly flagged
- **False negatives {r.fn:,}** - frauds missed (costly: money lost)
- **False positives {r.fp:,}** - legitimate customers flagged (cost: review effort, friction)
- **Threshold {r.threshold:.4f}** - selected to minimise weighted error cost on validation data
""")
        key = comp[comp.model == name].model_key.iloc[0]
        params = meta["models"].get(key, {}).get("best_params") or {}
        if params:
            st.markdown("**Tuned hyper-parameters**")
            st.json(params, expanded=False)
