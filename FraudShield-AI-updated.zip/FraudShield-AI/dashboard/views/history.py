"""Transaction history: filterable table of scored test transactions."""
from __future__ import annotations

import streamlit as st

from src import config

from .. import data
from ..components import explain_transaction
from ..theme import header


def render() -> None:
    run_id = data.version()
    meta, hist = data.metadata(run_id), data.history(run_id)
    best_key = meta["best_model"]
    header("Transaction History", "Search and filter scored transactions, then drill into any one of them")

    with st.container(border=True):
        c = st.columns([2, 2, 2, 3])
        risk = c[0].multiselect("Risk level", ["High", "Medium", "Low"], default=["High", "Medium"])
        pred = c[1].selectbox("Model decision", ["All", "Suspicious", "Not flagged"])
        actual = c[2].selectbox("Actual label", ["All", "Fraud", "Legitimate"])
        amax = float(hist.Amount.max())
        amt = c[3].slider("Amount range", 0.0, amax, (0.0, amax))
        query = st.text_input("Transaction ID contains", placeholder="e.g. TX-0001")

    f = hist[hist.risk_level.isin(risk or ["High", "Medium", "Low"])]
    if pred != "All":
        f = f[f.prediction == pred]
    if actual != "All":
        f = f[f.Class == (1 if actual == "Fraud" else 0)]
    f = f[f.Amount.between(*amt)]
    if query:
        f = f[f.transaction_id.str.contains(query.strip(), case=False, regex=False)]
    f = f.sort_values("risk_score", ascending=False)

    st.caption(f"Showing {len(f):,} of {len(hist):,} transactions - sorted by risk score - "
               f"model: {config.MODEL_NAMES[best_key]}")
    view = f[["transaction_id", "Time", "Amount", "risk_score", "risk_level", "prediction", "Class"]] \
        .assign(Class=lambda d: d.Class.map({1: "Fraud", 0: "Legitimate"}))
    st.dataframe(
        view.head(5000), hide_index=True, width="stretch", height=430,
        column_config={
            "transaction_id": "Transaction",
            "Time": st.column_config.NumberColumn("Time (s)", format="%d"),
            "Amount": st.column_config.NumberColumn("Amount", format="%.2f"),
            "risk_score": st.column_config.ProgressColumn("Risk score", min_value=0.0, max_value=1.0,
                                                                 format="%.4f"),
            "risk_level": "Risk", "prediction": "Model decision", "Class": "Actual label",
        },
    )
    if len(f) > 5000:
        st.caption("Table shows the top 5,000 rows; the download contains all filtered rows.")
    st.download_button("Download filtered rows (CSV)", f.to_csv(index=False).encode(),
                       "fraudshield_transactions.csv", "text/csv")

    st.divider()
    st.subheader("Explain a transaction")
    if f.empty:
        st.info("No transactions match the filters.")
        return
    tx = st.selectbox("Transaction", f.transaction_id.head(500).tolist())
    row = f[f.transaction_id == tx]
    r = row.iloc[0]
    st.markdown(f"**{tx}** - score **{r.risk_score:.4f}** ({r.risk_level} risk) - "
                f"model decision **{r.prediction}** - actual label **{'Fraud' if r.Class else 'Legitimate'}**")
    explain_transaction(row[config.RAW_FEATURES].reset_index(drop=True), best_key)
