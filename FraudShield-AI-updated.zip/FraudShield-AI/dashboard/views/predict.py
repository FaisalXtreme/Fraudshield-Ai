"""Individual and batch transaction scoring."""
from __future__ import annotations

import numpy as np
import pandas as pd
import streamlit as st

from src import config
from src.predict import risk_level

from .. import data
from ..components import disclaimer, explain_transaction, gauge, result_card
from ..theme import header

DEFAULTS = {"Time": 43200.0, "Amount": 75.0, **{f: 0.0 for f in config.PCA_FEATURES}}


def _init_state() -> None:
    for f, val in DEFAULTS.items():
        st.session_state.setdefault(f"in_{f}", val)


def _load_example(hist: pd.DataFrame, cls: int | None) -> None:
    pool = hist if cls is None else hist[hist.Class == cls]
    row = pool.sample(1, random_state=np.random.randint(1_000_000)).iloc[0]
    for f in config.RAW_FEATURES:
        st.session_state[f"in_{f}"] = float(row[f])
    st.session_state["example_note"] = (f"Loaded {row.transaction_id} from the test set "
                                        f"(actual label: {'Fraud' if row.Class else 'Legitimate'}).")


def _reset() -> None:
    for f, val in DEFAULTS.items():
        st.session_state[f"in_{f}"] = val
    st.session_state.pop("example_note", None)


def meta_threshold_note(model_key: str) -> str:
    return "weighted validation error cost"


def _single(model_key: str) -> None:
    hist = data.history(data.version())
    _init_state()
    c = st.columns(4)
    c[0].button("Load real fraud example", on_click=_load_example, args=(hist, 1), width="stretch")
    c[1].button("Load real legit example", on_click=_load_example, args=(hist, 0), width="stretch")
    c[2].button("Random test transaction", on_click=_load_example, args=(hist, None), width="stretch")
    c[3].button("Reset inputs", on_click=_reset, width="stretch")
    if "example_note" in st.session_state:
        st.caption(st.session_state["example_note"])

    with st.form("tx_form"):
        c1, c2 = st.columns(2)
        c1.number_input("Amount", min_value=0.0, step=1.0, format="%.2f", key="in_Amount",
                        help="Transaction amount (dataset currency: Euro)")
        c2.number_input("Time (seconds since first transaction)", min_value=0.0, step=60.0, format="%.0f",
                        key="in_Time", help="Encoded as a continuous daily-cycle sine/cosine pair")
        with st.expander("PCA features V1 - V28 (anonymised by the dataset publisher)", expanded=False):
            cols = st.columns(4)
            for i, f in enumerate(config.PCA_FEATURES):
                cols[i % 4].number_input(f, step=0.1, format="%.4f", key=f"in_{f}")
        submitted = st.form_submit_button("Analyze transaction", type="primary", width="stretch")

    if not submitted:
        st.info("Enter values or load an example, then click **Analyze transaction**.")
        return

    raw = pd.DataFrame([{f: float(st.session_state[f"in_{f}"]) for f in config.RAW_FEATURES}])
    try:
        pred = data.predictor(model_key, data.version())
        score = float(pred.score(raw)[0])
    except Exception as exc:
        st.error(f"Prediction failed: {exc}")
        return

    risk = risk_level(score, pred.threshold)
    c1, c2 = st.columns([3, 2])
    c1.plotly_chart(gauge(score, pred.threshold), width="stretch")
    with c2:
        st.write("")
        result_card(score, pred.threshold, risk, pred.label, meta_threshold_note(model_key))
    st.caption("This is a model risk score on a 0-1 scale, not a calibrated probability. Scores from "
               "different model families are not directly comparable; use the selected model's threshold.")
    disclaimer()
    st.write("")
    explain_transaction(raw, model_key)


def _batch(model_key: str) -> None:
    st.markdown(f"Upload a CSV with columns **{', '.join(['Time', 'V1', '...', 'V28', 'Amount'])}** "
                "(the `Class` column is optional and ignored for scoring).")
    up = st.file_uploader("Transactions CSV", type="csv")
    if up is None:
        return
    try:
        df = pd.read_csv(up)
        res = data.predictor(model_key, data.version()).predict(df)
    except Exception as exc:
        st.error(f"Could not score file: {exc}")
        return
    out = pd.concat([df.reset_index(drop=True), res], axis=1)
    n_s = int((res.prediction == "Suspicious").sum())
    c = st.columns(3)
    c[0].metric("Rows scored", f"{len(out):,}")
    c[1].metric("Flagged suspicious", f"{n_s:,}")
    c[2].metric("Flag rate", f"{100 * n_s / max(len(out), 1):.2f}%")
    st.dataframe(out.sort_values("risk_score", ascending=False), hide_index=True, width="stretch",
                 column_config={"risk_score": st.column_config.ProgressColumn(
                     "Risk score", min_value=0.0, max_value=1.0, format="%.4f")})
    st.download_button("Download results", out.to_csv(index=False).encode(), "fraudshield_scored.csv", "text/csv")
    disclaimer()


def render() -> None:
    meta = data.metadata(data.version())
    header("Analyze a Transaction", "Score a transaction, see its risk level, and understand why")
    keys = list(meta["models"])
    best = meta["best_model"]
    model_key = st.selectbox(
        "Model", keys, index=keys.index(best),
        format_func=lambda k: config.MODEL_NAMES[k] + ("  (best)" if k == best else ""),
    )
    t1, t2 = st.tabs(["Single transaction", "Batch CSV"])
    with t1:
        _single(model_key)
    with t2:
        _batch(model_key)
