"""Overview: KPIs and risk distribution on the held-out test transactions."""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from src import config

from .. import data
from ..theme import BLUE, GREEN, RED, RISK_COLORS, header, kpi, note, style_fig


def render() -> None:
    run_id = data.version()
    meta, hist = data.metadata(run_id), data.history(run_id)
    best_key = meta["best_model"]
    thr = meta["models"][best_key]["threshold"]
    header("Security Overview", f"{len(hist):,} held-out transactions scored by "
                                f"{config.MODEL_NAMES[best_key]} - never seen during training")

    total = len(hist)
    flagged = int((hist.prediction == "Suspicious").sum())
    not_flagged = total - flagged
    actual = int(hist.Class.sum())
    caught = int(((hist.prediction == "Suspicious") & (hist.Class == 1)).sum())

    c = st.columns(4)
    with c[0]:
        kpi("Transactions analyzed", f"{total:,}", "held-out test set", BLUE)
    with c[1]:
        kpi("Flagged as suspicious", f"{flagged:,}", f"{caught:,} of {actual:,} actual frauds caught", RED)
    with c[2]:
        kpi("Not flagged", f"{not_flagged:,}", f"{100 * not_flagged / total:.2f}% of transactions", BLUE)
    with c[3]:
        kpi("Fraud detection rate", f"{100 * caught / max(actual, 1):.1f}%",
            f"recall | {100 * flagged / total:.3f}% of volume flagged", "#A78BFA")
    st.write("")

    c1, c2 = st.columns([3, 2])
    with c1:
        fig = go.Figure()
        for cls, name, color in [(0, "Actually legitimate", BLUE), (1, "Actually fraud", RED)]:
            fig.add_histogram(x=hist.loc[hist.Class == cls, "risk_score"], name=name,
                              marker_color=color, nbinsx=50, opacity=0.8)
        fig.add_vline(x=thr, line_dash="dash", line_color="#E2E8F0",
                      annotation_text=f"threshold {thr:.2f}", annotation_font_color="#E2E8F0")
        fig.update_layout(barmode="overlay")
        fig.update_yaxes(type="log", title="Transactions (log)")
        fig.update_xaxes(title="Model risk score")
        st.plotly_chart(style_fig(fig, 380, "Risk score distribution"), width="stretch")
    with c2:
        counts = hist.risk_level.value_counts().reindex(["Low", "Medium", "High"]).fillna(0)
        fig = go.Figure(go.Pie(labels=counts.index, values=counts.values, hole=0.6,
                               marker_colors=[RISK_COLORS[r] for r in counts.index], sort=False,
                               textinfo="label+value"))
        st.plotly_chart(style_fig(fig, 380, "Transactions by risk level"), width="stretch")

    c1, c2 = st.columns(2)
    with c1:
        hist = hist.assign(hour=(hist.Time % 86400 // 3600).astype(int))
        by_hour = hist.groupby("hour").agg(flagged=("prediction", lambda s: (s == "Suspicious").sum()),
                                          total=("prediction", "size")).reset_index()
        fig = px.bar(by_hour, x="hour", y="flagged", color_discrete_sequence=[RED],
                     labels={"hour": "Elapsed-time cycle hour", "flagged": "Flagged transactions"})
        st.plotly_chart(style_fig(fig, 340, "Flagged transactions by elapsed-time cycle"), width="stretch")
    with c2:
        rest = hist[hist.Class == 0]
        sample = pd.concat([hist[hist.Class == 1], rest.sample(min(3000, len(rest)), random_state=0)])
        sample = sample.assign(Actual=np.where(sample.Class == 1, "Fraud", "Legitimate"))
        fig = px.scatter(sample, x="Amount", y="risk_score", color="Actual", opacity=0.6,
                         color_discrete_map={"Fraud": RED, "Legitimate": BLUE}, log_x=True,
                         hover_data=["transaction_id"], labels={"risk_score": "Risk score"})
        fig.update_traces(marker_size=5)
        st.plotly_chart(style_fig(fig, 340, "Amount vs risk score (all frauds + 3k legit sample)"),
                        width="stretch")

    note("Scores come from real model predictions on the held-out 20% test split of the Kaggle dataset. "
         "'Not flagged' does not prove a transaction is legitimate. 'Flagged' means the score is at or above the model's threshold; 'High / Medium / Low' "
         "risk are score bands relative to that threshold.")
