"""Global explainability (SHAP)."""
from __future__ import annotations

import plotly.graph_objects as go
import streamlit as st

from src import config

from .. import data
from ..theme import BLUE, RED, header, note, style_fig


def render() -> None:
    run_id = data.version()
    meta, imp = data.metadata(run_id), data.shap_importance(run_id)
    best = config.MODEL_NAMES[meta["best_model"]]
    header("Explainable AI", f"What drives {best}'s risk scores across many transactions (SHAP)")

    note("<b>How to read SHAP.</b> For each transaction, SHAP splits the model's output into a "
         "contribution per feature. Positive values push the score towards <span style='color:#F43F5E'>"
         "fraud</span>; negative values push it towards <span style='color:#3B82F6'>legitimate</span>. "
         "Global importance is the average size of those contributions over all frauds plus a "
         "1,000-transaction legitimate sample from the test set.")
    st.write("")

    if imp is None:
        st.warning("No SHAP report found. Install SHAP (`pip install shap`) and re-run `python train.py`.")
        return

    top = imp.head(15).iloc[::-1]
    fig = go.Figure(go.Bar(
        x=top.mean_abs_shap, y=top.feature, orientation="h",
        marker_color=[RED if s > 0 else BLUE for s in top.mean_shap],
        customdata=top.mean_shap, hovertemplate="%{y}<br>mean |SHAP| %{x:.4f}<br>mean SHAP %{customdata:+.4f}"
                                                "<extra></extra>",
    ))
    fig.update_xaxes(title="mean |SHAP value|")
    c1, c2 = st.columns([3, 2])
    c1.plotly_chart(style_fig(fig, 520, "Top 15 features by global importance"), width="stretch")
    with c2:
        st.markdown("##### Key findings")
        for _, r in imp.head(5).iterrows():
            direction = "raises" if r.mean_shap > 0 else "lowers"
            st.markdown(f"- **{r.feature}** - mean impact {r.mean_abs_shap:.4f}; on average it "
                        f"{direction} the score in this sample")
        st.caption(f"Explanation method: {meta.get('shap_method', 'n/a')}. "
                   "V1-V28 are PCA-transformed for confidentiality, so findings identify *which* signals "
                   "matter, not their real-world meaning. Amount and the elapsed-time cycle are available.")

    beeswarm = data.artifact_path(run_id, "reports/figures/10_shap_summary.png")
    if beeswarm.exists():
        st.subheader("SHAP summary (beeswarm)")
        st.caption("Each dot is a transaction; colour is the feature value (red high, blue low); "
                   "x-position is its impact on the score.")
        st.image(str(beeswarm), width="stretch")
    st.info("To see why a *specific* transaction was flagged, open **Transaction History** or **Analyze**.")
