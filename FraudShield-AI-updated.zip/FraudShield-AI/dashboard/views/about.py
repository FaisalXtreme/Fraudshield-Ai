"""Dataset, EDA figures and methodology."""
from __future__ import annotations

import streamlit as st

from src import config

from .. import data
from ..theme import header, note


def render() -> None:
    run_id = data.version()
    meta = data.metadata(run_id)
    ds, eda = meta["dataset"], meta.get("eda") or {}
    header("Data & Methodology", "Where the data comes from and how the models were built")

    c = st.columns(4)
    c[0].metric("Raw rows", f"{ds['rows_raw']:,}")
    c[1].metric("Duplicates removed", f"{ds['duplicate_rows_dropped']:,}")
    c[2].metric("Fraud cases", f"{ds['fraud_count']:,}")
    c[3].metric("Fraud rate", f"{100 * ds['fraud_rate']:.3f}%")

    st.markdown(f"""
**Dataset.** [Credit Card Fraud Detection]({config.DATASET_URL}) (ULB Machine Learning Group): two days
of European card transactions from September 2013. Features V1-V28 are PCA components (original features are
confidential); `Time` is seconds since the first transaction and `Amount` is the transaction value.

**Pipeline.**
1. Cleaning - dropped exact duplicate rows *before* splitting to prevent train/test leakage.
2. Split - {meta['split']['strategy']} train {ds['train_rows']:,} / validation {ds['val_rows']:,} / test {ds['test_rows']:,}.
3. Features - `Amount` -> log1p -> RobustScaler; `Time` -> continuous daily-cycle sine/cosine pair.
4. Fold-local transforms - preprocessing is part of each estimator pipeline, so every CV fold fits its own scaler;
   Random Forest SMOTE runs only inside each training fold.
5. Imbalance - Logistic Regression: class weights; Random Forest: SMOTE; XGBoost: `scale_pos_weight` = {meta['scale_pos_weight']:.0f}; Isolation Forest: unsupervised.
6. Tuning - randomized search with {meta['tuning']['cv_folds']}-fold {meta['split']['cv']}, optimising average precision (enabled: {meta['tuning']['enabled']}).
7. Threshold - minimum weighted false-negative / false-positive cost on validation data (weights {meta['threshold_selection']['false_negative_cost_weight']:g}:{meta['threshold_selection']['false_positive_cost_weight']:g}).
8. Selection - best model by validation PR-AUC: **{config.MODEL_NAMES[meta['best_model']]}**.
9. Reporting - metrics computed on the untouched latest-time test set.

Trained: {meta['trained_at']}
""")
    if eda:
        st.caption(f"Median amount - fraud {eda['amount_median_fraud']:.2f} vs legitimate "
                   f"{eda['amount_median_legit']:.2f}; imbalance {eda['imbalance_ratio']}.")

    figs = sorted(data.artifact_path(run_id, "reports/figures").glob("0[1-6]_*.png"))
    if figs:
        st.subheader("Exploratory data analysis")
        cols = st.columns(2)
        for i, p in enumerate(figs):
            cols[i % 2].image(str(p), width="stretch")

    note("<b>Limitations.</b> The data is from 2013, from one European issuer, over two days; patterns may not "
         "transfer to other markets or today's fraud tactics. Scores are risk estimates to prioritise human "
         "review, not determinations of fraud.")
