"""Streamlit dashboard for FraudShield AI."""
